import math
import numpy as np
import pandas as pd
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
root = tk.Tk()
root.title("Stokes Wave Calculations")
# Constants
g = 9.81  # gravity (m/s^2)
rho = 1025  # seawater density (kg/m^3)

# Load CSV data (make sure to place this CSV in the same directory or provide an absolute path)
data = pd.read_csv('run_data/details.csv')

def linear_wave_plot(x, y,z, T, H, depth,theta,index):
    r = x * np.sin(theta) + y * np.cos(theta)
    x = r
    # Find approximate depth (d) and wavelength (l) for (x, y)
    rounded_x_data = np.round(data['x'].values, 2)
    rounded_y_data = np.round(data['y'].values, 2)
    
    # index = np.where((abs(rounded_x_data - x) < 0.1) & (abs(rounded_y_data - y) < 0.1))
    # if len(index[0]) == 0:
    #     print(f"No matching point found for approximate coordinates ({x}, {y})")
    # print(index) 

    d = abs(data['Depth'].values[index])
    l = data['Wavelength'].values[index]
    ks = data['Shoaling Coefficient (ks)'].values[index]
    k = 2 * np.pi / l  # wave number
    
    # Celerity and energy
    C = l / T
    E = (1 / 8) * rho * g * H ** 2

    # Particle properties calculation
    def particle_properties(H, L, T, d, z, x, t):
        A = H / 2
        k = 2 * math.pi / L
        omega = 2 * math.pi / T
        u = A * omega * math.cosh(k * (z + d)) / math.sinh(k * d) * math.cos(k * x - omega * t)
        w = -A * omega * math.sinh(k * (z + d)) / math.sinh(k * d) * math.sin(k * x - omega * t)
        a_x = -A * omega ** 2 * math.cosh(k * (z + d)) / math.sinh(k * d) * math.cos(k * x - omega * t)
        a_z = -A * omega ** 2 * math.sinh(k * (z + d)) / math.sinh(k * d) * math.sin(k * x - omega * t)
        pressure = rho * g * z + (rho * g * A * (math.cosh(k * (z + d)) / math.cosh(k * d)) * math.sin(k * x - omega * t))
        return u, w, a_x, a_z, pressure

    # Prepare time series and data lists
    time_steps = np.linspace(0, 2*T, 100)
    u_values, w_values, a_x_values, a_z_values, pressure_values = [], [], [], [], []

    # Calculate over time
    for t in time_steps:
        u, w, a_x, a_z, pressure = particle_properties(H,l,T,d,z,x,t)
        u_values.append(u)
        w_values.append(w)
        a_x_values.append(a_x)
        a_z_values.append(a_z)
        pressure_values.append(pressure)

    # Plotting with Tkinter and Matplotlib
    root = tk.Tk()
    root.title("Wave Property Plots")

    fig = Figure(figsize=(10, 8))
    axs = [fig.add_subplot(3, 2, i + 1) for i in range(5)]

    # Horizontal velocity
    axs[0].plot(time_steps, u_values, label='Horizontal Velocity (u)', color='blue')
    axs[0].set_title('Horizontal Velocity (u)')
    axs[0].set_xlabel('Time (s)')
    axs[0].set_ylabel('u (m/s)')

    # Vertical velocity
    axs[1].plot(time_steps, w_values, label='Vertical Velocity (w)', color='green')
    axs[1].set_title('Vertical Velocity (w)')
    axs[1].set_xlabel('Time (s)')
    axs[1].set_ylabel('w (m/s)')

    # Horizontal acceleration
    axs[2].plot(time_steps, a_x_values, label='Horizontal Acceleration (a_x)', color='red')
    axs[2].set_title('Horizontal Acceleration (a_x)')
    axs[2].set_xlabel('Time (s)')
    axs[2].set_ylabel('a_x (m/s²)')

    # Vertical acceleration
    axs[3].plot(time_steps, a_z_values, label='Vertical Acceleration (a_z)', color='orange')
    axs[3].set_title('Vertical Acceleration (a_z)')
    axs[3].set_xlabel('Time (s)')
    axs[3].set_ylabel('a_z (m/s²)')

    # Pressure
    axs[4].plot(time_steps, pressure_values, label='Pressure', color='purple')
    axs[4].set_title('Pressure')
    axs[4].set_xlabel('Time (s)')
    axs[4].set_ylabel('Pressure (Pa)')

    # Add text
    fig.suptitle(f"Wavelength: {l:.2f} m, Shoaling Coefficient: {ks:.4f}, "
                 f"Updated Height: {H:.2f} m, Energy: {E:.2f} J/m²")

    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack()

    root.mainloop()



def linear_wave_plot_2(x, y,z, T, H, depth,theta,l):
    r = x * np.sin(theta) + y * np.cos(theta)
    x = r
    d = abs(depth)
    l = 1.56*T*T
    L = 0
    while abs(L - l) > 0.001:
        L = l
        try:
            l = 1.56 * T * T * math.tanh(2 * math.pi * d / l)
        except ZeroDivisionError:
            print("Error: Division by zero encountered in calculation. Check input values.")
            break
    # Find approximate depth (d) and wavelength (l) for (x, y)
    
    d = abs(depth)
    k = 2 * np.pi / l  # wave number

    # Celerity and energy
    C = l / T
    E = (1 / 8) * rho * g * H ** 2
    ks = 1  # Shoaling coefficient default

    # Update wave height if depth * wave number < 0.25 / π
    H_updated = H
    if d * k < 0.25 / np.pi:
        sinh_2kd = np.sinh(2 * k * d)
        n = 0.5 * (1 + (2 * k * d) / sinh_2kd)
        lo = 1.56 * T ** 2
        ks = np.sqrt(lo / (2 * n * l))
        H_updated = H * ks

    # Particle properties calculation
    def particle_properties(H, L, T, d, z, x, t):
        A = H / 2
        k = 2 * math.pi / L
        omega = 2 * math.pi / T
        u = A * omega * math.cosh(k * (z + d)) / math.sinh(k * d) * math.cos(k * x - omega * t)
        w = -A * omega * math.sinh(k * (z + d)) / math.sinh(k * d) * math.sin(k * x - omega * t)
        a_x = -A * omega ** 2 * math.cosh(k * (z + d)) / math.sinh(k * d) * math.cos(k * x - omega * t)
        a_z = -A * omega ** 2 * math.sinh(k * (z + d)) / math.sinh(k * d) * math.sin(k * x - omega * t)
        pressure = rho * g * z + (rho * g * A * (math.cosh(k * (z + d)) / math.cosh(k * d)) * math.sin(k * x - omega * t))
        return u, w, a_x, a_z, pressure

    # Prepare time series and data lists
    time_steps = np.linspace(0, T, 100)
    u_values, w_values, a_x_values, a_z_values, pressure_values = [], [], [], [], []

    # Calculate over time
    for t in time_steps:
        u, w, a_x, a_z, pressure = particle_properties(H_updated, l, T, depth,z, x, t)
        u_values.append(u)
        w_values.append(w)
        a_x_values.append(a_x)
        a_z_values.append(a_z)
        pressure_values.append(pressure)

    # Plotting with Tkinter and Matplotlib
    root = tk.Tk()
    root.title("Wave Property Plots")

    fig = Figure(figsize=(10, 8))
    axs = [fig.add_subplot(3, 2, i + 1) for i in range(5)]

    # Horizontal velocity
    axs[0].plot(time_steps, u_values, label='Horizontal Velocity (u)', color='blue')
    axs[0].set_title('Horizontal Velocity (u)')
    axs[0].set_xlabel('Time (s)')
    axs[0].set_ylabel('u (m/s)')

    # Vertical velocity
    axs[1].plot(time_steps, w_values, label='Vertical Velocity (w)', color='green')
    axs[1].set_title('Vertical Velocity (w)')
    axs[1].set_xlabel('Time (s)')
    axs[1].set_ylabel('w (m/s)')

    # Horizontal acceleration
    axs[2].plot(time_steps, a_x_values, label='Horizontal Acceleration (a_x)', color='red')
    axs[2].set_title('Horizontal Acceleration (a_x)')
    axs[2].set_xlabel('Time (s)')
    axs[2].set_ylabel('a_x (m/s²)')

    # Vertical acceleration
    axs[3].plot(time_steps, a_z_values, label='Vertical Acceleration (a_z)', color='orange')
    axs[3].set_title('Vertical Acceleration (a_z)')
    axs[3].set_xlabel('Time (s)')
    axs[3].set_ylabel('a_z (m/s²)')

    # Pressure
    axs[4].plot(time_steps, pressure_values, label='Pressure', color='purple')
    axs[4].set_title('Pressure')
    axs[4].set_xlabel('Time (s)')
    axs[4].set_ylabel('Pressure (Pa)')

    # Add text
    fig.suptitle(f"Wavelength: {l:.2f} m, Shoaling Coefficient: {ks:.4f},Wave Celerity m/s: {C:.4f}, "
                 f"Updated Height: {H_updated:.2f} m, Energy: {E:.2f} J/m²")

    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack()

    root.mainloop()

    return





def stokes_2nd_wave_plot(x, y,z, T, H, depth,theta,index):
    r = x * np.sin(theta) + y * np.cos(theta)
    x = r
    # Find approximate depth (d) and wavelength (l) for (x, y)
    rounded_x_data = np.round(data['x'].values, 2)
    rounded_y_data = np.round(data['y'].values, 2)
    
    # index = np.where((abs(rounded_x_data - x) < 0.1) & (abs(rounded_y_data - y) < 0.1))
    # if len(index[0]) == 0:
    #     print(f"No matching point found for approximate coordinates ({x}, {y})")
        

    d = abs(data['Depth'].values[index])
    l = data['Wavelength'].values[index]
    k = 2 * np.pi / l  # wave number
    C = l / T  # Celerity

    # Shoaling coefficient default
    ks = 1
    H_updated = H
    if d * k < 0.25 / np.pi:
        sinh_2kd = np.sinh(2 * k * d)
        n = 0.5 * (1 + (2 * k * d) / sinh_2kd)
        lo = 1.56 * T ** 2
        ks = np.sqrt(lo / (2 * n * l))
        H_updated = H * ks

    # Updated Particle Properties Calculation
    def particle_properties_2d(H, L, T, d, z, x, t):
        A = H / 2
        k = 2 * math.pi / L
        omega = 2 * math.pi / T

        # Horizontal velocity (u)
        u = A * omega * math.cosh(k * (z + d)) / math.cosh(k * d) * math.sin(k * x - omega * t) + \
            (0.75 * (np.pi * H / L)**2) * C * (np.cosh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.sin(2 * (k * x - omega * t))

        # Vertical velocity (w)
        w = A * omega * math.sinh(k * (z + d)) / math.cosh(k * d) * math.cos(k * x - omega * t) + \
            (0.75 * (np.pi * H / L)**2) * C * (np.sinh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.cos(2 * (k * x - omega * t))

        # Horizontal acceleration (a_x)
        a_x = A * omega ** 2 * math.cosh(k * (z + d)) / math.cosh(k * d) * math.cos(k * x - omega * t) + \
            (k * 3 / 8) * ((H * omega)**2) * (np.cosh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.cos(2 * (k * x - omega * t))

        # Vertical acceleration (a_z)
        a_z = -A * omega ** 2 * math.sinh(k * (z + d)) / math.cosh(k * d) * math.sin(k * x - omega * t) - \
            (k * 3 / 8) * ((H * omega)**2) * (np.sinh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.sin(2 * (k * x - omega * t))

        # Pressure
        pressure = - rho * g * z + (rho * g * A * (math.cosh(k * (z + d)) / math.cosh(k * d)) * math.sin(k * x - omega * t)) + \
            (3 / 8) * (rho * g) * (np.pi * H ** 2 / L) * (np.tanh(k * d) / np.sinh(k * d)**2) * \
            ((np.cosh(2 * k * (d + z)) / np.sinh(k * d)**2) - 1 / 3) * math.sin(2 * k * x - 2 * omega * t) + \
            (1 / 8) * (rho * g) * (np.pi * H ** 2 / L) * (np.tanh(k * d) / np.sinh(k * d)**2) * (np.cosh(2 * k * (d + z)) - 1)

        # Transport velocity (U)
        U = (np.pi * H ** 2 / L) * (C / 2) * (np.cosh(2 * k * (d + z)) / (np.sinh(k * d))**2)

        return u, w, a_x, a_z, pressure, U

    # Prepare time series and data lists
    time_steps = np.linspace(0, 2*T, 100)
    u_values, w_values, a_x_values, a_z_values, pressure_values, U_values = [], [], [], [], [], []

    # Calculate over time
    for t in time_steps:
        u, w, a_x, a_z, pressure, U = particle_properties_2d(H_updated, l, T, d, z, x, t)
        u_values.append(u)
        w_values.append(w)
        a_x_values.append(a_x)
        a_z_values.append(a_z)
        pressure_values.append(pressure)
        U_values.append(U)

    # Plotting with Tkinter and Matplotlib
    root = tk.Tk()
    root.title("Wave Property Plots")

    fig = Figure(figsize=(10, 10))
    axs = [fig.add_subplot(3, 2, i + 1) for i in range(6)]

    # Horizontal velocity
    axs[0].plot(time_steps, u_values, label='Horizontal Velocity (u)', color='blue')
    axs[0].set_title('Horizontal Velocity (u)')
    axs[0].set_xlabel('Time (s)')
    axs[0].set_ylabel('u (m/s)')

    # Vertical velocity
    axs[1].plot(time_steps, w_values, label='Vertical Velocity (w)', color='green')
    axs[1].set_title('Vertical Velocity (w)')
    axs[1].set_xlabel('Time (s)')
    axs[1].set_ylabel('w (m/s)')

    # Horizontal acceleration
    axs[2].plot(time_steps, a_x_values, label='Horizontal Acceleration (a_x)', color='red')
    axs[2].set_title('Horizontal Acceleration (a_x)')
    axs[2].set_xlabel('Time (s)')
    axs[2].set_ylabel('a_x (m/s²)')

    # Vertical acceleration
    axs[3].plot(time_steps, a_z_values, label='Vertical Acceleration (a_z)', color='orange')
    axs[3].set_title('Vertical Acceleration (a_z)')
    axs[3].set_xlabel('Time (s)')
    axs[3].set_ylabel('a_z (m/s²)')

    # Pressure
    axs[4].plot(time_steps, pressure_values, label='Pressure', color='purple')
    axs[4].set_title('Pressure')
    axs[4].set_xlabel('Time (s)')
    axs[4].set_ylabel('Pressure (Pa)')

    # Transport Velocity (U)
    axs[5].plot(time_steps, U_values, label='Transport Velocity (U)', color='brown')
    axs[5].set_title('Transport Velocity (U)')
    axs[5].set_xlabel('Time (s)')
    axs[5].set_ylabel('U (m/s)')

    # Add calculated properties as text
    fig.suptitle(f"Wavelength: {l:.2f} m, Shoaling Coefficient: {ks:.4f}, Updated Height: {H_updated:.2f} m, Energy: {(1 / 8) * rho * g * H ** 2:.2f} J/m²")

    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack()

    root.mainloop()
    return


def stokes_2nd_wave_plot_2(x, y,z, T, H, depth,theta,l):
    r = x * np.sin(theta) + y * np.cos(theta)
    x = r
    d = abs(depth)
    l = 1.56*T*T
    L = 0
    while abs(L - l) > 0.001:
        L = l
        try:
            l = 1.56 * T * T * math.tanh(2 * math.pi * d / l)
        except ZeroDivisionError:
            print("Error: Division by zero encountered in calculation. Check input values.")
            break
    # Find approximate depth (d) and wavelength (l) for (x, y)
    

    k = 2 * np.pi / l  # wave number
    C = l / T  # Celerity

    # Shoaling coefficient default
    ks = 1
    H_updated = H
    if d * k < 0.25 / np.pi:
        sinh_2kd = np.sinh(2 * k * d)
        n = 0.5 * (1 + (2 * k * d) / sinh_2kd)
        lo = 1.56 * T ** 2
        ks = np.sqrt(lo / (2 * n * l))
        H_updated = H * ks

    # Updated Particle Properties Calculation
    def particle_properties_2d(H, L, T, d, z, x, t):
        A = H / 2
        k = 2 * math.pi / L
        omega = 2 * math.pi / T

        # Horizontal velocity (u)
        u = A * omega * math.cosh(k * (z + d)) / math.cosh(k * d) * math.sin(k * x - omega * t) + \
            (0.75 * (np.pi * H / L)**2) * C * (np.cosh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.sin(2 * (k * x - omega * t))

        # Vertical velocity (w)
        w = A * omega * math.sinh(k * (z + d)) / math.cosh(k * d) * math.cos(k * x - omega * t) + \
            (0.75 * (np.pi * H / L)**2) * C * (np.sinh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.cos(2 * (k * x - omega * t))

        # Horizontal acceleration (a_x)
        a_x = A * omega ** 2 * math.cosh(k * (z + d)) / math.cosh(k * d) * math.cos(k * x - omega * t) + \
            (k * 3 / 8) * ((H * omega)**2) * (np.cosh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.cos(2 * (k * x - omega * t))

        # Vertical acceleration (a_z)
        a_z = -A * omega ** 2 * math.sinh(k * (z + d)) / math.cosh(k * d) * math.sin(k * x - omega * t) - \
            (k * 3 / 8) * ((H * omega)**2) * (np.sinh(2 * k * (z + d)) / (np.sinh(k * d)**4)) * \
            np.sin(2 * (k * x - omega * t))

        # Pressure
        pressure = - rho * g * z + (rho * g * A * (math.cosh(k * (z + d)) / math.cosh(k * d)) * math.sin(k * x - omega * t)) + \
            (3 / 8) * (rho * g) * (np.pi * H ** 2 / L) * (np.tanh(k * d) / np.sinh(k * d)**2) * \
            ((np.cosh(2 * k * (d + z)) / np.sinh(k * d)**2) - 1 / 3) * math.sin(2 * k * x - 2 * omega * t) + \
            (1 / 8) * (rho * g) * (np.pi * H ** 2 / L) * (np.tanh(k * d) / np.sinh(k * d)**2) * (np.cosh(2 * k * (d + z)) - 1)

        # Transport velocity (U)
        U = (np.pi * H ** 2 / L) * (C / 2) * (np.cosh(2 * k * (d + z)) / (np.sinh(k * d))**2)

        return u, w, a_x, a_z, pressure, U

    # Prepare time series and data lists
    time_steps = np.linspace(0, 2*T, 100)
    u_values, w_values, a_x_values, a_z_values, pressure_values, U_values = [], [], [], [], [], []

    # Calculate over time
    for t in time_steps:
        u, w, a_x, a_z, pressure, U = particle_properties_2d(H_updated, l, T, d, z, x, t)
        u_values.append(u)
        w_values.append(w)
        a_x_values.append(a_x)
        a_z_values.append(a_z)
        pressure_values.append(pressure)
        U_values.append(U)

    # Plotting with Tkinter and Matplotlib
    root = tk.Tk()
    root.title("Wave Property Plots")

    fig = Figure(figsize=(10, 10))
    axs = [fig.add_subplot(3, 2, i + 1) for i in range(6)]

    # Horizontal velocity
    axs[0].plot(time_steps, u_values, label='Horizontal Velocity (u)', color='blue')
    axs[0].set_title('Horizontal Velocity (u)')
    axs[0].set_xlabel('Time (s)')
    axs[0].set_ylabel('u (m/s)')

    # Vertical velocity
    axs[1].plot(time_steps, w_values, label='Vertical Velocity (w)', color='green')
    axs[1].set_title('Vertical Velocity (w)')
    axs[1].set_xlabel('Time (s)')
    axs[1].set_ylabel('w (m/s)')

    # Horizontal acceleration
    axs[2].plot(time_steps, a_x_values, label='Horizontal Acceleration (a_x)', color='red')
    axs[2].set_title('Horizontal Acceleration (a_x)')
    axs[2].set_xlabel('Time (s)')
    axs[2].set_ylabel('a_x (m/s²)')

    # Vertical acceleration
    axs[3].plot(time_steps, a_z_values, label='Vertical Acceleration (a_z)', color='orange')
    axs[3].set_title('Vertical Acceleration (a_z)')
    axs[3].set_xlabel('Time (s)')
    axs[3].set_ylabel('a_z (m/s²)')

    # Pressure
    axs[4].plot(time_steps, pressure_values, label='Pressure', color='purple')
    axs[4].set_title('Pressure')
    axs[4].set_xlabel('Time (s)')
    axs[4].set_ylabel('Pressure (Pa)')

    # Transport Velocity (U)
    axs[5].plot(time_steps, U_values, label='Transport Velocity (U)', color='brown')
    axs[5].set_title('Transport Velocity (U)')
    axs[5].set_xlabel('Time (s)')
    axs[5].set_ylabel('U (m/s)')

    # Add calculated properties as text
    fig.suptitle(f"Wavelength: {l:.2f} m, Shoaling Coefficient: {ks:.4f}, Updated Height: {H_updated:.2f} m, Energy: {(1 / 8) * rho * g * H ** 2:.2f} J/m²")

    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack()

    root.mainloop()
    return

def wave_celerity(L, T):
    return L / T

# Particle velocity function
def particle_velocity(L, T, H, d, x, z, t):
    k = 2 * np.pi / L
    omega = 2 * np.pi / T
    S = d + z
    F1 = (k * (H / 2)) / (np.sinh(k * d))
    F2 = (0.75 * (k * (H / 2)) ** 2) / (np.sinh(k * d)) ** 4
    F3 = (3 / 64) * ((k * (H / 2)) ** 3) * ((11 - (2 * np.cosh(2 * k * d))) / (np.sinh(k * d)) ** 7)
    u = (L / T) * ((F1 * np.cosh(k * S) * np.cos(k * x - omega * t)) + 
                   (F2 * np.cosh(2 * k * S) * np.cos(2 * (k * x - omega * t))) + 
                   (F3 * np.cosh(3 * k * S) * np.cos(3 * (k * x - omega * t))))
    w = (L / T) * ((F1 * np.sinh(k * S) * np.sin(k * x - omega * t)) + 
                   (F2 * np.sinh(2 * k * S) * np.sin(2 * (k * x - omega * t))) + 
                   (F3 * np.sinh(3 * k * S) * np.sin(3 * (k * x - omega * t))))
    return u, w

# Particle acceleration function
def particle_acceleration(L, T, H, d, x, z, t):
    k = 2 * np.pi / L
    omega = 2 * np.pi / T
    S = d + z
    F1 = (k * (H / 2)) / (np.sinh(k * d))
    F2 = (0.75 * (k * (H / 2)) ** 2) / (np.sinh(k * d)) ** 4
    F3 = (3 / 64) * ((k * (H / 2)) ** 3) * ((11 - (2 * np.cosh(2 * k * d))) / (np.sinh(k * d)) ** 7)
    ax = ((2 * np.pi * (L / T)**2) / L) * ((F1 * np.cosh(k * S) * np.sin(k * x - omega * t)) + 
                                             (2 * F2 * np.cosh(2 * k * S) * np.sin(2 * (k * x - omega * t))) + 
                                             (3 * F3 * np.cosh(3 * k * S) * np.sin(3 * (k * x - omega * t))))
    az = -((2 * np.pi * (L / T)**2) / L) * ((F1 * np.sinh(k * S) * np.cos(k * x - omega * t)) + 
                                             (2 * F2 * np.sinh(2 * k * S) * np.cos(2 * (k * x - omega * t))) + 
                                             (3 * F3 * np.sinh(3 * k * S) * np.cos(3 * (k * x - omega * t))))
    return ax, az

# Particle displacement function
def particle_displacement(L, T, H, d, x, z, t):
    k = 2 * np.pi / L
    omega = 2 * np.pi / T
    S = d + z
    F1 = (k * (H / 2)) / (np.sinh(k * d))
    F2 = (0.75 * (k * (H / 2)) ** 2) / (np.sinh(k * d)) ** 4
    F3 = (3 / 64) * ((k * (H / 2)) ** 3) * ((11 - (2 * np.cosh(2 * k * d))) / (np.sinh(k * d)) ** 7)
    eta_x = (-L / (2 * np.pi)) * (F1 * (1 - (F1**2 / 8)) * np.cosh(k * (d + z))) * np.sin(k * x - omega * t)
    eta_z = (L / (2 * np.pi)) * (F1 * (1 - ((3 * F1**2) / 8)) * np.sinh(k * (d + z))) * np.cos(k * x - omega * t)
    return eta_x, eta_z

# Combined function for plotting
def stokes3rd_wave_calculations( T, H, x,y, z,theta,index):
    r = x * np.sin(theta) + y * np.cos(theta)
    

    # Find approximate depth (d) and wavelength (l) for (x, y)
    rounded_x_data = np.round(data['x'].values, 2)
    rounded_y_data = np.round(data['y'].values, 2)
    
    # index = np.where((abs(rounded_x_data - x) < 0.1) & (abs(rounded_y_data - y) < 0.1))
    # if len(index[0]) == 0:
    #     print(f"No matching point found for approximate coordinates ({x}, {y})")
       
    d = abs(data['Depth'].values[index])
    L = data['Wavelength'].values[index]
    k = 2 * np.pi / L  # wave number
    x = r

    time_steps = np.linspace(0, 2*T, 100)
    celerity_values = [wave_celerity(L, T) for _ in time_steps]
    u_values, w_values, ax_values, az_values, eta_x_values, eta_z_values = [], [], [], [], [], []

    for t in time_steps:
        u, w = particle_velocity(L, T, H, d, x, z, t)
        ax, az = particle_acceleration(L, T, H, d, x, z, t)
        eta_x, eta_z = particle_displacement(L, T, H, d, x, z, t)

        u_values.append(u)
        w_values.append(w)
        ax_values.append(ax)
        az_values.append(az)
        eta_x_values.append(eta_x)
        eta_z_values.append(eta_z)

    # Tkinter GUI
    root = tk.Tk()
    root.title("Stokes Wave Calculations")

    fig = Figure(figsize=(10, 8))
    axs = [fig.add_subplot(3, 2, i + 1) for i in range(6)]

    # Plot properties
    axs[0].plot(time_steps, u_values, label='u (Horizontal Velocity)', color='blue')
    axs[0].set_title("Horizontal Velocity (u)")
    axs[0].set_xlabel("Time (s)")
    axs[0].set_ylabel("u (m/s)")

    axs[1].plot(time_steps, w_values, label='w (Vertical Velocity)', color='green')
    axs[1].set_title("Vertical Velocity (w)")
    axs[1].set_xlabel("Time (s)")
    axs[1].set_ylabel("w (m/s)")

    axs[2].plot(time_steps, ax_values, label='a_x (Horizontal Acceleration)', color='red')
    axs[2].set_title("Horizontal Acceleration (a_x)")
    axs[2].set_xlabel("Time (s)")
    axs[2].set_ylabel("a_x (m/s²)")

    axs[3].plot(time_steps, az_values, label='a_z (Vertical Acceleration)', color='purple')
    axs[3].set_title("Vertical Acceleration (a_z)")
    axs[3].set_xlabel("Time (s)")
    axs[3].set_ylabel("a_z (m/s²)")

    axs[4].plot(time_steps, eta_x_values, label='η_x (Horizontal Displacement)', color='orange')
    axs[4].set_title("Horizontal Displacement (η_x)")
    axs[4].set_xlabel("Time (s)")
    axs[4].set_ylabel("η_x (m)")

    axs[5].plot(time_steps, eta_z_values, label='η_z (Vertical Displacement)', color='brown')
    axs[5].set_title("Vertical Displacement (η_z)")
    axs[5].set_xlabel("Time (s)")
    axs[5].set_ylabel("η_z (m)")

    # Add canvas to Tkinter window
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack()

    root.mainloop()
    return
def stokes3rd_wave_calculations_2( T, H, x,y, z,theta,d,l):
    r = x * np.sin(theta) + y * np.cos(theta)
    
    L = l
    k = 2 * np.pi / L  # wave number
    x = r

    time_steps = np.linspace(0, 2*T, 100)
    celerity_values = [wave_celerity(L, T) for _ in time_steps]
    u_values, w_values, ax_values, az_values, eta_x_values, eta_z_values = [], [], [], [], [], []

    for t in time_steps:
        u, w = particle_velocity(L, T, H, d, x, z, t)
        ax, az = particle_acceleration(L, T, H, d, x, z, t)
        eta_x, eta_z = particle_displacement(L, T, H, d, x, z, t)

        u_values.append(u)
        w_values.append(w)
        ax_values.append(ax)
        az_values.append(az)
        eta_x_values.append(eta_x)
        eta_z_values.append(eta_z)

    # Tkinter GUI
    root = tk.Tk()
    root.title("Stokes Wave Calculations")

    fig = Figure(figsize=(10, 8))
    axs = [fig.add_subplot(3, 2, i + 1) for i in range(6)]

    # Plot properties
    axs[0].plot(time_steps, u_values, label='u (Horizontal Velocity)', color='blue')
    axs[0].set_title("Horizontal Velocity (u)")
    axs[0].set_xlabel("Time (s)")
    axs[0].set_ylabel("u (m/s)")

    axs[1].plot(time_steps, w_values, label='w (Vertical Velocity)', color='green')
    axs[1].set_title("Vertical Velocity (w)")
    axs[1].set_xlabel("Time (s)")
    axs[1].set_ylabel("w (m/s)")

    axs[2].plot(time_steps, ax_values, label='a_x (Horizontal Acceleration)', color='red')
    axs[2].set_title("Horizontal Acceleration (a_x)")
    axs[2].set_xlabel("Time (s)")
    axs[2].set_ylabel("a_x (m/s²)")

    axs[3].plot(time_steps, az_values, label='a_z (Vertical Acceleration)', color='purple')
    axs[3].set_title("Vertical Acceleration (a_z)")
    axs[3].set_xlabel("Time (s)")
    axs[3].set_ylabel("a_z (m/s²)")

    axs[4].plot(time_steps, eta_x_values, label='η_x (Horizontal Displacement)', color='orange')
    axs[4].set_title("Horizontal Displacement (η_x)")
    axs[4].set_xlabel("Time (s)")
    axs[4].set_ylabel("η_x (m)")

    axs[5].plot(time_steps, eta_z_values, label='η_z (Vertical Displacement)', color='brown')
    axs[5].set_title("Vertical Displacement (η_z)")
    axs[5].set_xlabel("Time (s)")
    axs[5].set_ylabel("η_z (m)")

    # Add canvas to Tkinter window
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack()

    root.mainloop()
    return

def constants(kd):
    try:
        safe_values = np.clip(kd, -709, 709)
        s = np.sinh(safe_values)
        c = np.cosh(safe_values)
        c = np.clip(c, -1e2, 1e2)  # Adjust limits as needed
        s = np.clip(s, -1e2, 1e2)
        if( c == 0):
            c = 1
        if ( s == 0):
            s = 1


        A11 = 1/s
      
        A13 = np.nan_to_num(-(c**2)*(5*(c**2) + 1)/(8*(s**5)), nan=0.0, posinf=1e+150, neginf=-1e+150)
       
        A15 = np.nan_to_num(-(1184*(c**10) - 1440*(c**8) - 1992*(c**6) + 2641*(c**4) - 249*(c**2)+ 18)/(1536*(s**11)), nan=0.0, posinf=1e+150, neginf=-1e+150)
        A22 = 3/(8*(s**4))

        A24 = np.nan_to_num((192*(c**8) - 424*(c**6) - 312*(c**4) + 480*(c**2) - 17)/(748*(s**10)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        A33 = np.nan_to_num((13 - 4*(c**2))/(64*(s**7)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        A35 = np.nan_to_num( (512*(c**12) + 4224*(c**10) - 6800*(c**8) - 12808*(c**6) + 16704*(c**4) - 3154*(c**2)+ 107)/(4096*(s**13)*(-1+ 6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        A44 = np.nan_to_num((80*(c**6) - 816*(c**4) + 1338*(c**2) - 197)/((1536*(s**10)*(-1+6*(c**2)))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        A55 = -( 2880*(c**10) - 72480*(c**8) + 324000*(c**6) - 432000*(c**4) + 163470*(c**2) - 16245)/(61440*(s**11)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4)))
        
        B22 = (1 + 2*(c**2))*c/(4*(s**3))

        B24 = np.nan_to_num(c*(272*(c**8) - 504*(c**6) - 192*(c**4) + 322*(c**2)+ 21)/(384*(s**9)), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B33 = np.nan_to_num((1 + 8*(c**6))*3/(64*(s**6)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        B35 = np.nan_to_num((88128*(c**14) - 208224*(c**12) + 70848*(c**10) + 54000*(c**8) - 21816*(c**6) + 6264*(c**4) - 54*(c**2)+ 81)/(12288*(s**12)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B44 = np.nan_to_num(c*(768*(c**10) - 448*(c**8) - 48*(c**6) + 48*(c**4) - 106*(c**2) -21)/(384*(s**9)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B55 = np.nan_to_num(-(192000*(c**16) - 262720*(c**14) + 83680*(c**12) + 20160*(c**10) - 7280*(c**8) + 7160*(c**6) - 1800*(c**4) - 1050*(c**2) + 225)/(12288*(s**10)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        C1 = (8*(c**4) - 8*(c**2) + 9)/(8*(s**4))
        C2 = (3840*(c**12) - 4096*(c**10) + 2592*(c**8) - 1008*(c**6) + 5944*(c**4) - 1830*(c**2)+ 147)/(512*(s**10)*(-1+6*(c**2)))
        C3 = -1/(4*s*c)

        C4 = np.nan_to_num(( 12*(c**8) + 36*(c**6) - 162*(c**4) + 141*(c**2) - 27)/(192*(s**9)*c), nan=0.0, posinf=1e+150, neginf=-1e+150)
    except:
        KeyError("check parameters")



    return A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4




def stokes_wave_calculations( T, H, x, y, z,theta,o,d,l,index):
        # Find approximate depth (d) and wavelength (l) for (x, y)
    
    k = 2 * np.pi / l
    r = x * np.sin(theta) + y * np.cos(theta)
    x = r
    d = d
    la = 0
    new_kd = 2 * np.pi * d / l
    Kd = 1
    counter = 0


    while abs((2 * (np.pi) * d / Kd) - (2 * (np.pi) * d / new_kd)) > 0.01:

        Kd = new_kd
        A11, A13, A15, A22, A24, A33, A35, A44, A55, B22, B24, B33, B35, B44, B55, C1, C2, C3, C4 = constants(Kd)

        # Solve the system of equations
        coefficients = [B55 + B35, 0, B33, 0, 1, -(H * Kd) / (2 * d)]
        if not np.any(np.isnan(coefficients)) and not np.any(np.isinf(coefficients)):
            L_prime = np.roots(coefficients)
        else:
            # Handle the case where coefficients are invalid
            L_prime = np.array([np.nan])
            break  # or any other fallback value
        L_prime = L_prime[np.isreal(L_prime)].real[0]
        la = L_prime

        # Step 2: Recalculate Kd using the second equation
        new_kd = (4 * np.pi ** 2 * d) / (g * T ** 2) / (np.tanh(new_kd) * (1 + C1 * L_prime ** 2 + C2 * L_prime ** 4))
        
        counter += 1
        if counter == 20:
            break

    kd = new_kd
    L = 2 * (np.pi) * d / kd
    A11, A13, A15, A22, A24, A33, A35, A44, A55, B22, B24, B33, B35, B44, B55, C1, C2, C3, C4 = constants(kd)

    # More constants
    C5 = abs((g * d / kd) * np.tanh(kd) * (1 + C1 * la ** 2 + C2 * la ** 4))  # Celerity
    A1 = (A11 * la ** 1 + A13 * la ** 3 + A15 * la ** 5)
    A2 = (A22 * la ** 2 + A24 * la ** 4)
    A3 = (A33 * la ** 3 + A35 * la ** 5)
    A4 = (A44 * la ** 4)
    A5 = (A55 * la ** 5)
    B3 = (B33 * la ** 3 + B35 * la ** 5)
    B2 = (B22 * la ** 2 + B24 * la ** 4)
    B5 = (A55 * la ** 5)
    B4 = (B44 * la ** 4)
    B1 = (la)
    k = kd / d
    z = - z
    # Functions for calculating properties
    def horizontal_velocity(z, o):
        return (C5) * (A1 * (np.cosh(k * (d - z))) * (np.cos((k + 2 * np.pi * o / T))) +
                       2 * A2 * (np.cosh(2 * k * (d - z))) * (np.cos(2 * (k +2 * np.pi * o / T))) +
                       3 * A3 * (np.cosh(3 * k * (d - z))) * (np.cos(3 * (k +2 * np.pi * o / T))) +
                       4 * A4 * (np.cosh(4 * k * (d - z))) * (np.cos(4 * (k +2 * np.pi * o / T))) +
                       5 * A5 * (np.cosh(5 * k * (d - z))) * (np.cos(5 * (k +2 * np.pi * o / T))))

    def vertical_velocity(z, o):
        return (C5) * (A1 * (np.sinh(k * (d - z))) * (np.sin((k +2 * np.pi * o / T))) +
                       2 * A2 * (np.sinh(2 * k * (d - z))) * (np.sin(2 * (k +2 * np.pi * o / T))) +
                       3 * A3 * (np.sinh(3 * k * (d - z))) * (np.sin(3 * (k +2 * np.pi * o / T))) +
                       4 * A4 * (np.sinh(4 * k * (d - z))) * (np.sin(4 * (k +2 * np.pi * o / T))) +
                       5 * A5 * (np.sinh(5 * k * (d - z))) * (np.sin(5 * (k +2 * np.pi * o / T))))

    def horizontal_acceleration(z, o):
        return (C5 * 2 * np.pi / T) * (A1 * (np.cosh(k * (d - z))) * (np.sin((k +2 * np.pi * o / T))) +
                                        4 * A2 * (np.cosh(2 * k * (d - z))) * (np.sin(2 * (k +2 * np.pi * o / T))) +
                                        9 * A3 * (np.cosh(3 * k * (d - z))) * (np.sin(3 * (k +2 * np.pi * o / T))) +
                                        16 * A4 * (np.cosh(4 * k * (d - z))) * (np.sin(4 * (k +2 * np.pi * o / T))) +
                                        25 * A5 * (np.cosh(5 * k * (d - z))) * (np.sin(5 * (k +2 * np.pi * o / T))))

    def vertical_acceleration(z, o):
        return (-C5 * 2 * np.pi / T) * (A1 * (np.sinh(k * (d - z))) * (np.cos((k +2 * np.pi * o / T))) +
                                         4 * A2 * (np.sinh(2 * k * (d - z))) * (np.cos(2 * (k +2 * np.pi * o / T))) +
                                         9 * A3 * (np.sinh(3 * k * (d - z))) * (np.cos(3 * (k +2 * np.pi * o / T))) +
                                         16 * A4 * (np.sinh(4 * k * (d - z))) * (np.cos(4 * (k +2 * np.pi * o / T))) +
                                         25 * A5 * (np.sinh(5 * k * (d - z))) * (np.cos(5 * (k +2 * np.pi * o / T))))

    return horizontal_velocity(z,o), vertical_velocity(z,o), horizontal_acceleration(z,o), vertical_acceleration(z,o), C5,L

# Function to perform calculations and get the wave properties
def calculate_wave_properties(T, H, x, z,y,d,l,alpha,index):

    # Time array for plotting
    time_points = np.linspace(0, 2 * T, 100)

    # Get the wave property calculation functions
    horizontal_velocity, vertical_velocity, horizontal_acceleration, vertical_acceleration, C5,L = stokes_wave_calculations(T, H ,x, y, z,alpha, time_points,d,l,index)

        
    return time_points, horizontal_velocity, vertical_velocity, horizontal_acceleration, vertical_acceleration,C5, L

# Function to plot wave properties on the Tkinter canvas
def plot_wave_properties(T, H, x, z,y,d,l,alpha,index):
    time_steps, u_values, w_values, a_x_values, a_z_values,C,l = calculate_wave_properties(T, H, x, z,y,d,l,alpha,index)
    root = tk.Tk()
    root.title("Stokes Wave Calculations")

    fig = Figure(figsize=(10, 8))
    axs = [fig.add_subplot(2, 2, i + 1) for i in range(4)]

    # Plot properties
    axs[0].plot(time_steps, u_values, label='u (Horizontal Velocity)', color='blue')
    axs[0].set_title("Horizontal Velocity (u)")
    axs[0].set_xlabel("Time (s)")
    axs[0].set_ylabel("u (m/s)")

    axs[1].plot(time_steps, w_values, label='w (Vertical Velocity)', color='green')
    axs[1].set_title("Vertical Velocity (w)")
    axs[1].set_xlabel("Time (s)")
    axs[1].set_ylabel("w (m/s)")

    axs[2].plot(time_steps, a_x_values, label='a_x (Horizontal Acceleration)', color='red')
    axs[2].set_title("Horizontal Acceleration (a_x)")
    axs[2].set_xlabel("Time (s)")
    axs[2].set_ylabel("a_x (m/s²)")

    axs[3].plot(time_steps, a_z_values, label='a_z (Vertical Acceleration)', color='purple')
    axs[3].set_title("Vertical Acceleration (a_z)")
    axs[3].set_xlabel("Time (s)")
    axs[3].set_ylabel("a_z (m/s²)")
    fig.suptitle(f"Wavelength: {l:.2f} m,Wave Celerity: {C:.2f} m/sec, Energy: {(1 / 8) * rho * g * H ** 2:.2f} J/m²")

    # Add canvas to Tkinter window
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack()

    root.mainloop()

    return