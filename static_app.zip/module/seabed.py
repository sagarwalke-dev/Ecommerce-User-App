import numpy as np
from scipy.interpolate import RBFInterpolator
from scipy.ndimage import gaussian_filter
from scipy.interpolate import griddata
import os
import pandas as pd

def create_seabed_plot(depths, x_coords, y_coords, x_length, y_length, x_partition, y_partition):
    depths = -np.array(depths)  # Convert depths to negative for seabed plotting

    try:
        # Create grid for interpolation
        x = np.linspace(0, x_length, x_partition)
        y = np.linspace(0, y_length, y_partition)
        X, Y = np.meshgrid(x, y)
        
        # Prepare points and values for interpolation
        points = np.array(list(zip(x_coords, y_coords)))
        values = depths

        # Interpolation and Extrapolation based on number of points
        if len(points) >= 3:  # Require at least three points for RBFInterpolator in 2D
            interpolator = RBFInterpolator(points, values, neighbors=min(10, len(points)), smoothing=0.1)
            Z = interpolator(np.column_stack((X.ravel(), Y.ravel()))).reshape(X.shape)
        elif len(points) == 2:
            # For two points, create a linear depth plane or average
           Z = griddata(points, values, (X, Y), method='nearest')
        elif len(points) == 1:
            Z = np.full_like(X, values[0])  # Use a constant depth for a single point
        else:
            print("Warning: Insufficient points for interpolation/extrapolation. Returning a flat NaN surface.")
            Z = np.full_like(X, np.nan)

        # Smooth the Z surface if there are no NaN values
        if Z is not None and not np.isnan(Z).all():
            Z = gaussian_filter(Z, sigma=1)

        # Handle cases where Z may be None or fully NaN
        if Z is None or np.isnan(Z).all():
            print("Warning: Z values are empty or all NaN. Returning a flat NaN surface.")
            Z = np.full_like(X, np.nan)

        # Mean Sea Level (MSL)
        Z_msl = np.zeros_like(X)

        save_depth_data(X, Y, Z)

        # Return the plot data
        return {'x': X.tolist(), 'y': Y.tolist(), 'z': Z.tolist(), 'msl': Z_msl.tolist()}

    except Exception as e:
        print("Error during interpolation and plotting:", e)
        return None

def save_depth_data(X, Y, Z):
    # Create 'run_data' directory if it doesn't exist
    os.makedirs('run_data', exist_ok=True)

    # Create a DataFrame from the depth data
    depth_data = {
        'X': X.flatten(),
        'Y': Y.flatten(),
        'Depth': Z.flatten()
    }
    df = pd.DataFrame(depth_data)

    # Save DataFrame to a CSV file
    file_path = os.path.join('run_data', 'depth.csv')
    df.to_csv(file_path, index=False)
    print(f"Depth data saved to {file_path}")