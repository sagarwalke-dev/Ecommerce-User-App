import numpy as np
import pandas as pd


# Load the CSV file
file_path = 'utility\wavelength_with_angles.csv'
data = pd.read_csv(file_path)

# Function to calculate Kr
def calculate_Kr(row):
    # Extract necessary values
    d = row['Depth']
    l = row['l']
    ratio = row['depth_wavelength_ratio']
    
    try:
        theta_0 = row['incident_angle']
    except:
        ratio = np.ones(np.shape(l))


    # If depth to wavelength ratio > 0.5, set Kr to 1
    if ratio > 0.5:
        return 1
    
    # If theta_0 is NaN, set Kr to 1
    if np.isnan(theta_0):
        return 1
    
    # Calculate k = 2*pi / l
    k = 2 * np.pi / l
    
    # Calculate sinh(kd)
    tanh_kd = np.tanh(k * abs(d))  # depth is negative, so abs(d)
    
    # Calculate sin(theta) = sin(theta_0) * tanh(kd)
    sin_theta_0 = np.sin(np.radians(theta_0))
    sin_theta = sin_theta_0 * tanh_kd
    
    # Ensure sin(theta) does not exceed 1 (arcsin domain)
    sin_theta = np.clip(sin_theta, -1, 1)
    
    # Calculate theta
    theta = np.degrees(np.arcsin(sin_theta))
    
    # Calculate Kr = sqrt(cos(theta_0) / cos(theta))
    cos_theta_0 = np.cos(np.radians(theta_0))
    cos_theta = np.cos(np.radians(theta))
    Kr = np.sqrt(cos_theta_0 / cos_theta)
    
    return Kr

# Apply the function to each row in the dataset
data['Kr'] = data.apply(calculate_Kr, axis=1)

# Show the result with Kr
try:
    data[['X', 'Y', 'l', 'Depth', 'depth_wavelength_ratio', 'incident_angle', 'Kr']].head()
except:
    data[['X', 'Y', 'l', 'Depth', 'depth_wavelength_ratio', 'Kr']].head()

data.to_csv('utility\wavelength_with_kr.csv', index=False)
