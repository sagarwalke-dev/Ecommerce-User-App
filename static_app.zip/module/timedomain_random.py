import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import messagebox

def process_and_plot_wave_data(filename, canvas_frame):
    try:
        # Read matrix from CSV
        A = np.genfromtxt(filename, delimiter=',')
        c = 0

        # Generate time array
        t = np.arange(0, len(A)) / 40

        if A.ndim == 1:
            e = A * 0.03332  # Directly scale if 1D
        elif A.ndim == 2 and A.shape[1] > 2:
            e = A[:, 2] * 0.03332  # Extract and scale the third column
        else:
            messagebox.showerror("Error", "Input file does not have enough columns")
            return
        
        D = np.column_stack((t, e))
        D = D[(D[:, 0] > 18) & (D[:, 0] < 100)]

        # Initialize variables
        m, n = D.shape
        c = 0
        l = 0

        # Find zero-crossings
        t1 = []
        for i in range(m - 1):
            if D[i, 1] > 0 and D[i + 1, 1] < 0:  # Down crossing
                c += 1
                t1.append([i, D[i, 0]])
                l = max(l, i)

        t1 = np.array(t1)
        H = np.zeros((l, c - 1))

        # Calculate wave heights
        for j in range(c - 1):
            k = 0
            for i in range(int(t1[j, 0]), int(t1[j + 1, 0])):
                H[k, j] = D[i, 1]
                k += 1

        # Calculate crest and trough heights
        crest = np.max(H, axis=0)
        trough = np.min(H, axis=0)
        ht = crest - trough
        Ht_sorted = np.sort(ht)[::-1]  # Sorting in descending order

        # Calculate significant wave height and H1/10
        N1_3 = round((c - 1) / 3)
        N1_10 = round((c - 1) / 10)
        H1_3 = Ht_sorted[:N1_3]
        H1_10 = Ht_sorted[:N1_10]
        Hs = np.mean(H1_3)
        H10 = np.mean(H1_10)
        print(H10)
        print(Hs)

        # Calculate zero-crossing period
        T = np.diff(t1[:, 1])
        Tz = np.mean(T)

        # Plot on matplotlib figure
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(D[:, 0], D[:, 1], linewidth=0.8)
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Elevation η in (m)')
        ax.set_title('Wave Elevation Time Series - Random Wave')
        
        # Display calculated values on the plot
        ax.text(0.05, 0.95, f'Tz: {Tz:.2f} s', transform=ax.transAxes, fontsize=10, verticalalignment='top')
        ax.text(0.05, 0.90, f'Hs: {Hs:.2f} m', transform=ax.transAxes, fontsize=10, verticalalignment='top')
        ax.text(0.05, 0.85, f'H1/10: {H10:.2f} m', transform=ax.transAxes, fontsize=10, verticalalignment='top')
        ax.grid()

        # Clear previous canvas if exists
        for widget in canvas_frame.winfo_children():
            widget.destroy()

        # Draw plot on tkinter canvas
        canvas = FigureCanvasTkAgg(fig, master=canvas_frame)
        canvas.draw()
        canvas.get_tk_widget().pack()

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

def create_gui(filename):
    root = tk.Tk()
    root.title("Wave Data Plotter")

    # Canvas frame for the plot
    canvas_frame = tk.Frame(root)
    canvas_frame.pack(padx=10, pady=10)

    # Directly call the plotting function with provided filename
    process_and_plot_wave_data(filename, canvas_frame)

    root.mainloop()


