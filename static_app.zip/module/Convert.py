import netCDF4 as nc
import pandas as pd
import numpy as np
import os

def convert(uploaded_file):
    # Define paths for the temporary NetCDF file and output CSV file
    nc_file_path = os.path.join('utility', uploaded_file.filename)
    csv_file_path = os.path.join('utility', os.path.splitext(uploaded_file.filename)[0] + '_converted.csv')
    
    # Save the uploaded file to the utility directory
    uploaded_file.save(nc_file_path)

    # Load GEBCO data from the NetCDF file
    with nc.Dataset(nc_file_path) as ds:
        gebco_depth = ds.variables['elevation'][:]
        gebco_lat = ds.variables['lat'][:]
        gebco_lon = ds.variables['lon'][:]

    # Display the size of the extracted data
    print('Size of GEBCO Depth Data:', gebco_depth.shape)
    print('Size of GEBCO Latitude Data:', gebco_lat.shape)
    print('Size of GEBCO Longitude Data:', gebco_lon.shape)

    # Create a meshgrid for latitude and longitude
    LON, LAT = np.meshgrid(gebco_lon, gebco_lat)

    # Flatten the data for CSV export
    depth_flat = gebco_depth.flatten()  # Flatten depth data
    lat_flat = LAT.flatten()            # Flatten latitude data
    lon_flat = LON.flatten()            # Flatten longitude data

    # Create a DataFrame to store the results with updated column names
    results = pd.DataFrame({
        'latitude': lat_flat,
        'longitude': lon_flat,
        'grid_code': depth_flat
    })

    # Write the results to the CSV file
    results.to_csv(csv_file_path, index=False)

    print(f'GEBCO data exported to {csv_file_path}')
