import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from mpl_toolkits.mplot3d import Axes3D
from scipy.ndimage import gaussian_filter
from scipy.interpolate import griddata
import os
import tkinter as tk
from tkinter import messagebox
from matplotlib.widgets import RectangleSelector


def save_depth_data(X, Y, Z):
    os.makedirs('run_data', exist_ok=True)

    depth_data = {
        'X': X.flatten(),
        'Y': Y.flatten(),
        'Depth': Z.flatten()
    }
    df = pd.DataFrame(depth_data)

    file_path = os.path.join('run_data', 'depth.csv')
    df.to_csv(file_path, index=False)
    print(f"Depth data saved to {file_path}")

def save_3d_plot(X, Y, Z, output_path="static/bed.png"):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_trisurf(X.flatten(), Y.flatten(), Z.flatten(), cmap='viridis')
    plt.colorbar(ax.plot_trisurf(X.flatten(), Y.flatten(), Z.flatten(), cmap='viridis'), ax=ax, shrink=0.5, aspect=5)
    plt.savefig(output_path)
    plt.close(fig)
    return output_path

def select_area_and_get_data(file_path):
    try:
        data = pd.read_csv(file_path)
        x_coords = data['X'].values
        y_coords = data['Y'].values
        depths = data['Depth'].values
    except KeyError:
        raise ValueError("The CSV file must contain 'X', 'Y', and 'Depth' columns.")
    except FileNotFoundError:
        raise ValueError("File not found. Please check the file path.")

    selected_points = []

    root = tk.Tk()
    root.title("Select Area")

    fig, ax = plt.subplots()
    grid_x, grid_y = np.linspace(x_coords.min(), x_coords.max(), 100), np.linspace(y_coords.min(), y_coords.max(), 100)
    grid_x, grid_y = np.meshgrid(grid_x, grid_y)
    grid_depth = griddata((x_coords, y_coords), depths, (grid_x, grid_y), method='cubic')

    contour = ax.contourf(grid_x, grid_y, grid_depth, cmap='viridis')
    plt.colorbar(contour, ax=ax, label='Depth')

    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    def onselect(eclick, erelease):
        x_min, y_min = eclick.xdata, eclick.ydata
        x_max, y_max = erelease.xdata, erelease.ydata

        mask = (
            (x_coords >= min(x_min, x_max)) & (x_coords <= max(x_min, x_max)) &
            (y_coords >= min(y_min, y_max)) & (y_coords <= max(y_min, y_max))
        )
        selected_x = x_coords[mask]
        selected_y = y_coords[mask]
        selected_depth = depths[mask]

        if len(selected_x) > 0:
            smoothed_depth = gaussian_filter(selected_depth, sigma=1)
            selected_points.extend(zip(selected_x, selected_y, smoothed_depth))

            ax.text(0.5, 1.05, 'Area Selected', transform=ax.transAxes, fontsize=12, color='red', ha='center')
            plt.draw()

            x_selected, y_selected, depth_selected = zip(*selected_points)
            x_selected = np.array(x_selected) - min(x_selected)
            y_selected = np.array(y_selected) - min(y_selected)

            save_depth_data(np.array(x_selected), np.array(y_selected), np.array(depth_selected))

            image_path = save_3d_plot(np.array(x_selected), np.array(y_selected), np.array(depth_selected))
            # root.after(0,lambda:messagebox.showinfo("Info", f"Depth data and 3D plot image saved successfully! Image path: {image_path}"))

    selector = RectangleSelector(ax, onselect, useblit=True, button=[1],
                                 minspanx=5, minspany=5, spancoords='pixels',
                                 interactive=True)

    close_button = tk.Button(root, text="Close", command=root.quit)
    close_button.pack(side=tk.BOTTOM)

    root.mainloop()

    if selected_points:
        x_selected, y_selected, depth_selected = zip(*selected_points)
        return {
            'x': np.array(x_selected).tolist(),
            'y': np.array(y_selected).tolist(),
            'z': np.array(depth_selected).tolist(),
            'msl': np.zeros_like(x_selected).tolist()
        }
    else:
        return {
            'x': [], 'y': [], 'z': [], 'msl': []
        }

# Example usage
# select_area_and_get_data("your_file_path.csv")
