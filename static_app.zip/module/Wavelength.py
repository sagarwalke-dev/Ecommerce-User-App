import pandas as pd
import numpy as np
from scipy import interpolate
import argparse

parser = argparse.ArgumentParser(description='Calculate wavelength')

parser.add_argument('--T', type=float, required=True, help='Wave period in seconds')

args = parser.parse_args()


t = args.T  # Wave period (from command-line argument)

# Load the wave table and updated depths CSV files
wave_table = pd.read_csv('utility\Wave_table.csv')
updated_depths = pd.read_csv('run_data\depth.csv')

# Assuming wave_table has columns 'd/lo' and 'd/l', and updated_depths has columns 'x', 'y', and the actual depth column
theory_column = 'Theory' 
depth_column = 'Depth'  
x_column = 'X'  
y_column = 'Y'  

# Filter out rows where depth is NaN
updated_depths = updated_depths.dropna(subset=[depth_column])

# Check for missing values in wave_table
if wave_table[['d/lo', 'd/l']].isnull().values.any():
    print("Warning: Missing values detected in 'Wave_table.csv' for 'd/lo' or 'd/l' columns.")
    wave_table.dropna(subset=['d/lo', 'd/l'], inplace=True)

# 1. Interpolation function for d/lo to d/l
try:
    interpolator = interpolate.interp1d(wave_table['d/lo'], wave_table['d/l'], kind='linear', fill_value="extrapolate")
except ValueError as e:
    print(f"Error creating interpolator: {e}")
    print("Ensure that 'd/lo' and 'd/l' have matching ranges in 'Wave_table.csv'.")
    raise

# 2. Define function to calculate lo based on time t
def calculate_lo(t):
    return 1.56 * t * t
    

# 3. Calculate wavelength (l) using the interpolated d/l and calculated lo
def calculate_l(depth, t):
    lo = calculate_lo(t)
    dlo_ratio = abs(depth) / lo  # Ensure depth is positive for ratio calculation
    if dlo_ratio > 0.5 :
        l_value = lo
    elif dlo_ratio < min(wave_table['d/lo']) or dlo_ratio > max(wave_table['d/lo']) or depth > 0:
        l_value = 0
    else:
        dl_value = interpolator(dlo_ratio)  # Interpolated d/l value
        l_value = abs(depth) / dl_value  # Calculate wavelength l
    return l_value



# 5. Apply the calculation to each row in the filtered updated_depths dataframe
try:
    updated_depths['l'] = updated_depths[depth_column].apply(lambda d: calculate_l(d, t))
    updated_depths[theory_column] = "Linear (Airy) Wave Theory"
except Exception as e:
    print(f"Error during wavelength calculation: {e}")
    raise

# 6. Save the new dataframe with 'x', 'y', 'l', and 'Depth' into a new CSV file
output_filename = 'utility\wavelength.csv'
updated_depths[[x_column, y_column, 'l', depth_column,theory_column]].to_csv(output_filename, index=False)

