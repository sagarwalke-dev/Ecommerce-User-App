import math
import numpy as np
import pandas as pd
import argparse
# Constants
g = 9.81  # acceleration due to gravity (m/s^2)
rho = 1025  # density of seawater (kg/m^3)

# Load data from CSV
data = pd.read_csv('utility\wavelength_with_kr.csv')

# Set up argument parsing to get values from command-line inputs
parser = argparse.ArgumentParser(description='Calculate Wave height')
parser.add_argument('--T', type=float, required=True, help='Wave period in seconds')
parser.add_argument('--H', type=float, required=True, help='Wave height in meters')

args = parser.parse_args()

# Round the input x and y to two decimal places
T = args.T  # Wave period (from command-line argument)
H = args.H  # Wave height (from command-line argument)

# Extract x, y, depth (d), and wavelength (l) columns from the dataset
x_data = data['X'].values
y_data = data['Y'].values
d_data = data['Depth'].values
l_data = data['l'].values
kr_data = data['Kr'].values

# Initialize arrays to store calculated results for each point
ks_values = []
H_updated_values = []

# Loop through each point in the data and calculate values
for i in range(len(x_data)):
    x = x_data[i]
    y = y_data[i]
    d = abs(d_data[i])
    l = l_data[i]
    kr = kr_data[i]

    # Wave number (k)
    try:
        k = 2 * np.pi / l

        # Calculate shoaling coefficient (ks) and updated wave height (H_updated)
        H_updated = H
        ks = 1  # Shoaling coefficient default is 1 (no change)
        if d /l < 0.5:
            sinh_2kd = np.sinh(2 * k * d)
            n = 0.5 * (1 + ((2 * k * d) / sinh_2kd))
            lo = 1.56 * T * T
            ks = np.sqrt(lo / (2 * n * l))
            H_updated = H * ks
    except:
        H_updated = 0
        ks = 1

    # Store the calculated values in arrays
    ks_values.append(ks)
    H_updated_values.append(H_updated)

# Create a DataFrame with the results
output_data = pd.DataFrame({
    'x': x_data,
    'y': y_data,
    'Depth': d_data,
    'Wavelength': l_data,
    'Shoaling Coefficient (ks)': ks_values,
    'Refraction Coefficient (Kr)': kr_data,
    'Updated Wave Height': H_updated_values,

})

# Save the DataFrame to a CSV file
output_data.to_csv('utility/WaveHeight.csv', index=False)

print("Wave data for all points has been saved to 'waveheight.csv'.")
