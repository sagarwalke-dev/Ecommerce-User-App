import math
import numpy as np
import pandas as pd
import argparse
# Constants
g = 9.81  # acceleration due to gravity (m/s^2)
rho = 1025  # density of seawater (kg/m^3)

# Load data from CSV
data = pd.read_csv('utility\WaveHeight.csv')

# Set up argument parsing to get values from command-line inputs
parser = argparse.ArgumentParser(description='Calculate Wave properties for the wave')
parser.add_argument('--T', type=float, required=True, help='Wave period in seconds')
parser.add_argument('--A', type=float, required=True, help='degrees, with respect to global north')

args = parser.parse_args()

# Round the input x and y to two decimal places
T = args.T  # Wave period (from command-line argument)
theta = args.A

# Extract x, y, depth (d), and wavelength (l) columns from the dataset
x_data = data['x'].values
y_data = data['y'].values
d_data = data['Depth'].values
l_data = data['Wavelength'].values
H_data = data['Updated Wave Height'].values
theory = data['Theory'].values
ks_data = data['Shoaling Coefficient (ks)'].values
kr_data = data['Refraction Coefficient (Kr)'].values

# Initialize arrays to store calculated results for each point

C_values = []
E_values = []
u_values = []
w_values = []
a_x_values = []
a_z_values = []
pressure_values = []
transport_vel =[]
wave_breaking = []  # New array to store if the wave is breaking



# for stroke 3rd order #####################################################################################

# Function to calculate wave celerity
def wave_celerity(L, T):
    return L / T


# Function to calculate water particle velocities
def particle_velocity(L, T, H, d, x, z, t):
    k = 2 * np.pi / L  # Wave number
    omega = 2 * np.pi / T  # Angular frequency
    S = d + z
    F1 = (k*(H/2))/(np.sinh(k*d))
    F2 = (0.75*(k*(H/2))**2)/(np.sinh(k*d))**4
    F3 = (3/64)*((k*(H/2))**3)*((11 - (2*np.cosh(2*k*d)))/(np.sinh(k*d))**7)
    # Velocities in x (horizontal) and z (vertical) directions
    u = (L/T)*((F1*np.cosh(k*S)*np.cos(k*x - omega*t))+(F2*np.cosh(2*k*S)*np.cos(2*(k*x - omega*t)))+(F3*np.cosh(3*k*S)*np.cos(3*(k*x - omega*t))))
    w = (L / T)*((F1 * np.sinh(k * S) * np.sin(k * x - omega * t)) + (F2 * np.sinh(2 * k * S) * np.sin(2 * (k * x - omega * t))) + (F3 * np.sinh(3 * k * S) * np.sin(3 * (k * x - omega * t))))


    return u, w


# Function to calculate accelerations in x and z directions
def particle_acceleration(L, T, H, d, x, z, t):
    k = 2 * np.pi / L  # Wave number
    omega = 2 * np.pi / T  # Angular frequency
    S = d + z
    F1 = (k * (H / 2)) / (np.sinh(k * d))
    F2 = (0.75 * (k * (H / 2)) ** 2) / (np.sinh(k * d)) ** 4
    F3 = (3 / 64) * ((k * (H / 2)) ** 3) * ((11 - (2 * np.cosh(2 * k * d))) / (np.sinh(k * d)) ** 7)

    # Accelerations in x (horizontal) and z (vertical) directions
    ax = ((2 * np.pi * (L/T)**2)/L)*((F1*np.cosh(k*S)*np.sin(k*x - omega*t))+(2*F2*np.cosh(2*k*S)*np.sin(2*(k*x - omega*t)))+(3*F3*np.cosh(3*k*S)*np.sin(3*(k*x - omega*t))))
    az = (-1)*((2 * np.pi * (L/T)**2)/L)*((F1*np.sinh(k*S)*np.cos(k*x - omega*t))+(2*F2*np.sinh(2*k*S)*np.cos(2*(k*x - omega*t)))+(3*F3*np.sinh(3*k*S)*np.cos(3*(k*x - omega*t))))

    return ax, az


# Function to calculate particle displacements in x and z directions
def particle_displacement(L, T, H, d, x, z, t):
    k = 2 * np.pi / L  # Wave number
    omega = 2 * np.pi / T  # Angular frequency
    S = d + z
    F1 = (k * (H / 2)) / (np.sinh(k * d))
    F2 = (0.75 * (k * (H / 2)) ** 2) / (np.sinh(k * d)) ** 4
    F3 = (3 / 64) * ((k * (H / 2)) ** 3) * ((11 - (2 * np.cosh(2 * k * d))) / (np.sinh(k * d)) ** 7)

    # Displacements in x (horizontal) and z (vertical) directions
    eta_x = ((-1)*(L/2*np.pi)*((F1 * (1 - ((F1**2)/8)) * np.cosh(k*(d+z))) + ((F1/8) * ((3 * F1**3)+(10*F2)) * np.cosh(3*k*(d+z))))*np.sin(k*x- omega*t)) - ((L/(4*np.pi))*(((F1**2)/2) + (F2 * np.cosh(2*k*(d+z))))) - ((L/(6*np.pi))*(((F1/4)*((F1**2) - (5*F2))*np.cosh(k*(d+z))) + (F3*np.cosh(3*k*(d+z)))*np.sin(3*(k*x-omega*t)))) + (L/2*T)*(F1**2)*((np.cosh(2*k*(d+z)))-(F1*(np.cosh(k*(d+z)))*(np.cosh(2*k*(d+z)))*np.cos(k*x - omega*t)))
    eta_z = ((L/2*np.pi)*((F1 * (1 - ((3*F1**2)/8)) * np.sinh(k*(d+z))) + ((F1/8) * ((F1**2)+(6*F2)) * np.sinh(3*k*(d+z))))*np.cos(k*x- omega*t)) - ((L/(4*np.pi))*((F2 * np.sinh(2*k*(d+z))))) + ((L/(6*np.pi))*((((-1)*3*F1*F2/4)*np.sinh(k*(d+z))) + (F3*np.sinh(3*k*(d+z)))*np.cos(3*(k*x-omega*t)))) - (L/2*T)*(F1**3)*((np.sinh(k*(d+z)))*(np.cosh(2*k*(d+z)))*np.sin(k*x-omega*t))

    return eta_x, eta_z


def stokes_wave_calculations(L,T, d, H, x, z, t):

    C = wave_celerity(L, T)

    # Velocities
    u, w = particle_velocity(L, T, H, d, x, z, t)

    # Accelerations
    ax, az = particle_acceleration(L, T, H, d, x, z, t)

    # Displacements
    eta_x, eta_z = particle_displacement(L, T, H, d, x, z, t)

    return C, u,w,ax,az,eta_x,eta_z


#######################################################################################################################3
def constants(kd):
    try:
        safe_values = np.clip(kd, -709, 709)
        s = np.sinh(safe_values)
        c = np.cosh(safe_values)
        c = np.clip(c, -1e2, 1e2)  # Adjust limits as needed
        s = np.clip(s, -1e2, 1e2)
        if( c == 0):
            c = 1
        if ( s == 0):
            s = 1


        A11 = 1/s
      
        A13 = np.nan_to_num(-(c**2)*(5*(c**2) + 1)/(8*(s**5)), nan=0.0, posinf=1e+150, neginf=-1e+150)
       
        A15 = np.nan_to_num(-(1184*(c**10) - 1440*(c**8) - 1992*(c**6) + 2641*(c**4) - 249*(c**2)+ 18)/(1536*(s**11)), nan=0.0, posinf=1e+150, neginf=-1e+150)
        A22 = 3/(8*(s**4))

        A24 = np.nan_to_num((192*(c**8) - 424*(c**6) - 312*(c**4) + 480*(c**2) - 17)/(748*(s**10)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        A33 = np.nan_to_num((13 - 4*(c**2))/(64*(s**7)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        A35 = np.nan_to_num( (512*(c**12) + 4224*(c**10) - 6800*(c**8) - 12808*(c**6) + 16704*(c**4) - 3154*(c**2)+ 107)/(4096*(s**13)*(-1+ 6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        A44 = np.nan_to_num((80*(c**6) - 816*(c**4) + 1338*(c**2) - 197)/((1536*(s**10)*(-1+6*(c**2)))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        A55 = -( 2880*(c**10) - 72480*(c**8) + 324000*(c**6) - 432000*(c**4) + 163470*(c**2) - 16245)/(61440*(s**11)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4)))
        
        B22 = (1 + 2*(c**2))*c/(4*(s**3))

        B24 = np.nan_to_num(c*(272*(c**8) - 504*(c**6) - 192*(c**4) + 322*(c**2)+ 21)/(384*(s**9)), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B33 = np.nan_to_num((1 + 8*(c**6))*3/(64*(s**6)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        B35 = np.nan_to_num((88128*(c**14) - 208224*(c**12) + 70848*(c**10) + 54000*(c**8) - 21816*(c**6) + 6264*(c**4) - 54*(c**2)+ 81)/(12288*(s**12)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B44 = np.nan_to_num(c*(768*(c**10) - 448*(c**8) - 48*(c**6) + 48*(c**4) - 106*(c**2) -21)/(384*(s**9)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B55 = np.nan_to_num(-(192000*(c**16) - 262720*(c**14) + 83680*(c**12) + 20160*(c**10) - 7280*(c**8) + 7160*(c**6) - 1800*(c**4) - 1050*(c**2) + 225)/(12288*(s**10)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        C1 = (8*(c**4) - 8*(c**2) + 9)/(8*(s**4))
        C2 = (3840*(c**12) - 4096*(c**10) + 2592*(c**8) - 1008*(c**6) + 5944*(c**4) - 1830*(c**2)+ 147)/(512*(s**10)*(-1+6*(c**2)))
        C3 = -1/(4*s*c)

        C4 = np.nan_to_num(( 12*(c**8) + 36*(c**6) - 162*(c**4) + 141*(c**2) - 27)/(192*(s**9)*c), nan=0.0, posinf=1e+150, neginf=-1e+150)
    except:
        KeyError("check parameters")



    return A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4




#######################################################################################################################





# Function to calculate particle velocity, pressure, and acceleration at the given point
def particle_properties(H, L, T, d, z, x, t,theory):

            # Calculate wave energy (E)
    E = (1 / 8) * rho * g * H ** 2


    A = H / 2  # amplitude (half of the wave height)
    k = 2 * math.pi / L  # wave number (k = 2π / L)
    omega = 2 * math.pi / T  # angular frequency (ω = 2π / T)

    # Wave number (k)
    k = 2 * np.pi / L

    if(theory == 'Stokes 2nd Order Wave Theory'):
        C = L/T

        # Horizontal velocity (u)
        u = A * omega * math.cosh(k * (z + d)) / math.cosh(k * d) * math.sin(k * x - omega * t) + (0.75*(np.pi*H/L)**2)*C*(np.cosh(2*k*(z+d))/((np.sinh(k*d))**4))*(np.sin(2*(k * x - omega * t)))

        # Vertical velocity (w)
        w = A * omega * math.sinh(k * (z + d)) / math.cosh(k * d) * math.cos(k * x - omega * t) + (0.75*(np.pi*H/L)**2)*C*(np.sinh(2*k*(z+d))/((np.sinh(k*d))**4))*(np.cos(2*(k * x - omega * t)))

        # Horizontal acceleration (a_x)
        a_x = A * omega ** 2 * math.cosh(k * (z + d)) / math.cosh(k * d) * math.cos(k * x - omega * t) + (k*3/8)*((H*omega)**2)*(np.cosh(2*k*(z+d))/((np.sinh(k*d))**4))*(np.cos(2*(k * x - omega * t)))

        # Vertical acceleration (a_z)
        a_z = -A * omega ** 2 * math.sinh(k * (z + d)) / math.cosh(k * d) * math.sin(k * x - omega * t) - (k*3/8)*((H*omega)**2)*(np.sinh(2*k*(z+d))/((np.sinh(k*d))**4))*(np.sin(2*(k * x - omega * t)))

        # Pressure at depth z
        pressure = - rho * g * z + (rho * g * A * (math.cosh(k * (z + d)) / math.cosh(k * d)) * math.sin(k * x - omega * t)) + (3/8)*(rho*g)*(np.pi*H*H/L)*(np.tanh(k*d)/(np.sinh(k*d))**2)*((np.cosh(2*k*(d+z))/(np.sinh(k*d))**2) - 1/3)*math.sin(2*k * x - 2*omega * t)  +  (1/8)*(rho*g)*(np.pi*H*H/L)*(np.tanh(k*d)/(np.sinh(k*d))**2)*(np.cosh(2*k*(d+z)) - 1)

        # transport velocity
        U = (np.pi*H*H/L)*(C/2)*(np.cosh(2*k*(d + z))/(np.sinh(k*d))**2)   

    elif(theory == 'Stokes 3rd Order Wave Theory'):
        C, u,w,a_x,a_z, eta_x, eta_z = stokes_wave_calculations(L,T, d, H, x, z, t)
        pressure = 0
        U = 0

    elif(d/L > 0.07 and theory== 'Stokes 5th Order Wave Theory'):
        la = 1
        new_kd = 2*np.pi*d/L
        Kd = 2*np.pi*d/1.56/T**2
        counter = 0
        while(abs((2*(np.pi)*d/Kd) - (2*(np.pi)*d/new_kd)) > 0.01 ):
            Kd = new_kd
            A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4 = constants(Kd)

            # Solve the system of equations
            coefficients = [B55 + B35, 0, B33, 0, 1, -(H * Kd) / (2 * d)]
            if not np.any(np.isnan(coefficients)) and not np.any(np.isinf(coefficients)):
                L_prime = np.roots(coefficients)
            else:
                # Handle the case where coefficients are invalid
                L_prime = np.array([np.nan])
                break  # or any other fallback value

            L_prime = L_prime[np.isreal(L_prime)].real[0]  # Use the real root
            la = L_prime

    
            # Step 2: Recalculate Kd using the second equation
            new_kd = (4 * np.pi**2 * d) / (g * T**2) / (np.tanh(new_kd) * (1 + C1 * L_prime**2 + C2 * L_prime**4))
            counter += 1
            if counter == 20:
                break


        kd = new_kd
        L = 2*(np.pi)*d/kd
        A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4 = constants(kd)


        # more constants
        C5 = abs((g*d/kd)*np.tanh(kd)*(1 + C1*la**2 + C2*la**4)) # celerity
        A1 = (A11*la**1 + A13*la**3 + A15*la**5)
        A2 = (A22*la**2 + A24*la**4)
        A3 = (A33*la**3 + A35*la**5)
        A4 = (A44*la**4)
        A5 = (A55*la**5)
        B3 = (B33*la**3 + B35*la**5)
        B2 = (B22*la**2 + B24*la**4)
        B5 = (A55*la**5)
        B4 = (B44*la**4)
        B1 = (la)
        k = kd/d
        

        # Functions for calculating properties
        def horizontal_velocity(z, o):
            return (C5)*(A1*(np.cosh(k*(d-z)))*(np.cos((2*np.pi*o/T))) + 2*A2*(np.cosh(2*k*(d-z)))*(np.cos(2*(2*np.pi*o/T))) + 3*A3*(np.cosh(3*k*(d-z)))*(np.cos(3*(2*np.pi*o/T))) + 4*A4*(np.cosh(4*k*(d-z)))*(np.cos(4*(2*np.pi*o/T))) + 5*A5*(np.cosh(5*k*(d-z)))*(np.cos(5*(2*np.pi*o/T))))

        def vertical_velocity(z, o):
            return (C5)*(A1*(np.sinh(k*(d-z)))*(np.sin((2*np.pi*o/T))) + 2*A2*(np.sinh(2*k*(d-z)))*(np.sin(2*(2*np.pi*o/T))) + 3*A3*(np.sinh(3*k*(d-z)))*(np.sin(3*(2*np.pi*o/T))) + 4*A4*(np.sinh(4*k*(d-z)))*(np.sin(4*(2*np.pi*o/T))) + 5*A5*(np.sinh(5*k*(d-z)))*(np.sin(5*(2*np.pi*o/T))))

        def horizontal_acceleration(z, o):
            return (C5*2*np.pi/T)*(A1*(np.cosh(k*(d-z)))*(np.sin((2*np.pi*o/T))) + 4*A2*(np.cosh(2*k*(d-z)))*(np.sin(2*(2*np.pi*o/T))) + 9*A3*(np.cosh(3*k*(d-z)))*(np.sin(3*(2*np.pi*o/T))) + 16*A4*(np.cosh(4*k*(d-z)))*(np.sin(4*(2*np.pi*o/T))) + 25*A5*(np.cosh(5*k*(d-z)))*(np.sin(5*(2*np.pi*o/T))))

        def vertical_acceleration(z, o):
            return (-C5*2*np.pi/T)*(A1*(np.sinh(k*(d-z)))*(np.cos((2*np.pi*o/T))) + 4*A2*(np.sinh(2*k*(d-z)))*(np.cos(2*(2*np.pi*o/T))) + 9*A3*(np.sinh(3*k*(d-z)))*(np.cos(3*(2*np.pi*o/T))) + 16*A4*(np.sinh(4*k*(d-z)))*(np.cos(4*(2*np.pi*o/T))) + 25*A5*(np.sinh(5*k*(d-z)))*(np.cos(5*(2*np.pi*o/T))))

        u = horizontal_velocity(x, t)
        w = vertical_velocity(x, t)
        a_x = horizontal_acceleration(x, t)
        a_z = vertical_acceleration(x, t)
        pressure = 0
        U = 0
        C = np.sqrt(C5)

    else:
        # Calculate celerity (C)
        C = L / T

        # Horizontal velocity (u)
        u = A * omega * math.cosh(k * (z + d)) / math.sinh(k * d) * math.cos(k * x - omega * t)

        # Vertical velocity (w)
        w = -A * omega * math.sinh(k * (z + d)) / math.sinh(k * d) * math.sin(k * x - omega * t)

        # Horizontal acceleration (a_x)
        a_x = -A * omega ** 2 * math.cosh(k * (z + d)) / math.sinh(k * d) * math.cos(k * x - omega * t)

        # Vertical acceleration (a_z)
        a_z = -A * omega ** 2 * math.sinh(k * (z + d)) / math.sinh(k * d) * math.sin(k * x - omega * t)

        # Pressure at depth z
        pressure = rho * g * z + (rho * g * A * (math.cosh(k * (z + d)) / math.cosh(k * d)) * math.sin(k * x - omega * t))
        #transport velocity
        U = 0


    return u, w, a_x, a_z, pressure,C,E,U

# Loop through each point in the data and calculate values
for i in range(len(x_data)):
    x = x_data[i]
    y = y_data[i]
    d = abs(d_data[i])
    l = l_data[i]
    H = H_data[i]
    r = x * np.sin(theta) + y * np.cos(theta)

    # Time and depth (z = 0, time = 0)
    z = 0
    t = 0
    if(H == 0 or l == 0):
        u, w, a_x, a_z, pressure, C , E, U = 0,0,0,0,0,0,0,0
    # Calculate particle properties
    else:
        u, w, a_x, a_z, pressure, C , E, U = particle_properties(H, l, T, d, z, r, t,theory[i])

    # Check for wave breaking
    if (l==0) or (H / l > 1 / 7) or (u > C) or (a_z > 9.81) or (H > 0.78*d):
        wave_breaking.append('yes')
    else:
        wave_breaking.append('no')

    # Store the calculated values in arrays
    C_values.append(C)
    E_values.append(E)
    u_values.append(u)
    w_values.append(w)
    a_x_values.append(a_x)
    a_z_values.append(a_z)
    pressure_values.append(pressure)
    transport_vel.append(U)

# Create a DataFrame with the results
output_data = pd.DataFrame({
    'x': x_data,
    'y': y_data,
    'Depth': d_data,
    'Wavelength': l_data,
    'Shoaling Coefficient (ks)': ks_data,
    'Refraction Coefficient (Kr)':kr_data,
    'Updated Wave Height': H_data,
    'Theory': theory,
    'Celerity (C)': C_values,
    'Wave Energy (E)': E_values,
    'Horizontal Velocity (u)': u_values,
    'Vertical Velocity (w)': w_values,
    'Horizontal Acceleration (a_x)': a_x_values,
    'Vertical Acceleration (a_z)': a_z_values,
    'Pressure': pressure_values,
    'transport velocity' : transport_vel,
    'Wave Breaking': wave_breaking  # New column for wave breaking status
})

# Save the DataFrame to a CSV file
output_data.to_csv('run_data\details.csv', index=False)

print("Wave data for all points has been saved to 'details.csv'.")
