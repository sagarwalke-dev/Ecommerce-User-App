import subprocess
import math
import pandas as pd
import module.wavetheory as wt
import numpy as np
import module.Revise_wavelength as rw
import module.plot as plot
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import pandas as pd
from matplotlib.animation import FuncAnimation
import subprocess
from tkinter import Tk, Label, Entry, Button, messagebox
from matplotlib.widgets import Button as mplButton
from scipy.spatial import KDTree
import math
import csv

data = pd.read_csv('run_data/details.csv')
filename = 'run_data/details.csv'
# Extract X, Y, depth, and wavelength
x = data['x'].values
y = data['y'].values

X, Y = np.meshgrid(np.unique(x), np.unique(y))

points = np.c_[X.ravel(), Y.ravel()]  # Flatten the grid for KDTree
tree = KDTree(points)


filename = 'run_data/details.csv'
def find_nearest_point(filename, target_x, target_y):
    data = pd.read_csv(filename)  # Load the CSV file
    x = data['x'].values
    y = data['y'].values
    
    nearest_point = None
    min_dist = np.inf
    
    for i in range(len(x)):
        distance = math.sqrt((x[i] - target_x)**2 + (y[i] - target_y)**2)
        
        # Update nearest point if the current distance is smaller
        if distance < min_dist:
            min_dist = distance
            nearest_point = (x[i], y[i],i)

    return nearest_point



    points = []
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        
        for row in reader:
            try:
                # Convert x and y values to float and add to points list
                x = float(row['x'])
                y = float(row['y'])
                points.append((x, y))
                
                # Debug: Print each point and its distance from the target
                distance = math.sqrt((x - target_x)**2 + (y - target_y)**2)
                print(f"Point: ({x}, {y}), Distance from target: {distance}")
                
            except ValueError as e:
                print(f"Skipping row with invalid data: {row}. Error: {e}")

    if not points:
        raise ValueError("No valid data points found in the CSV file.")

    # Find the nearest point based on Euclidean distance
    nearest_point = min(points, key=lambda p: math.sqrt((p[0] - target_x)**2 + (p[1] - target_y)**2))
    return nearest_point

def validate_and_run(x_val, y_val,Search_radius):
    # Check if the point is within the grid using KDTree
    dist, index = tree.query((x_val, y_val))  # Find nearest point to (x_val, y_val)
    nearest_point = points[index]

    # Check if the distance to the nearest point is within a small tolerance (e.g., 1e-3)
    if dist > 10:  # If the entered point is not close to any grid point
        # Find all nearby points within a radius of 5 units
        suggested_indices = tree.query_ball_point((x_val, y_val), r= Search_radius)
        suggested_points = points[suggested_indices]
        
        # Format the suggested points for displaying
        suggestions = ', '.join([f'({p[0]:.2f}, {p[1]:.2f})' for p in suggested_points])

        # Show an error message with nearby point suggestions
        message = (f"Point ({x_val}, {y_val}) does not exist. "
                   f"Please select a nearby point.\n"
                   f"Suggested nearby points: {suggestions}")
        messagebox.showerror("Invalid Point", message)
        return False
    else:
        # If the point is valid, run the detail.py script for the nearest valid point
        return nearest_point[0],nearest_point[1]

def solve(z,d,h,t,alpha):
    z = -float(z)
    d = float(d)
    t = float(t)
    alpha = float(alpha)

    l = 1
    theory = 'Linear (Airy) Wave Theory'
    while(True):
        k = 2 * np.pi / l

        # Calculate shoaling coefficient (ks) and updated wave height (H_updated)
        ks = 1  # Shoaling coefficient default is 1 (no change)
        if d * k < 0.25 / np.pi:
            sinh_2kd = np.sinh(2 * k * d)
            n = 0.5 * (1 + (2 * k * d) / sinh_2kd)
            lo = 1.56 * t* t
            ks = np.sqrt(lo / (2 * n * l))
            h = h * ks

        if d/l > 0.5:

            kr = 1
        else:
            tanh_kd = np.tanh(k * abs(d))  # depth is negative, so abs(d)
        
            # Calculate sin(theta) = sin(theta_0) * tanh(kd)
            sin_theta_0 = np.sin(np.radians(alpha))
            sin_theta = sin_theta_0 * tanh_kd
            
            # Ensure sin(theta) does not exceed 1 (arcsin domain)
            sin_theta = np.clip(sin_theta, -1, 1)
            
            # Calculate theta
            theta = np.degrees(np.arcsin(sin_theta))
            
            # Calculate Kr = sqrt(cos(theta_0) / cos(theta))
            cos_theta_0 = np.cos(np.radians(alpha))
            cos_theta = np.cos(np.radians(theta))
            kr = np.sqrt(cos_theta_0 / cos_theta)
        
        h = h*kr
        h = float(h)
        alpha = float(alpha)

        new_theory = wt.select_wave_theory_with_boundaries(float(h), float(d), t)

        if(theory != new_theory):
            l= rw.revise(l,h,d,t,new_theory,theory)
            theory = new_theory
        else: 
            break
    
    if(theory == 'Stokes 5th Order Wave Theory' and d/l > 0.07):
        result = plot.plot_wave_properties(t,h,0,z,0,d,l,alpha,0)

    elif(theory == "Stokes 3rd Order Wave Theory"):
        result = plot.stokes3rd_wave_calculations_2( t, h, 0,0, z,alpha,d,l)
    elif(theory == "Stokes 2nd Order Wave Theory"):
        result = plot.stokes_2nd_wave_plot_2(0,0,z,t,h,d,alpha,l)
    else:
        result = plot.linear_wave_plot_2(0,0,z,t,h,d,alpha,l)
    return result

def plotter(z,y,x,t,alpha,r):
    data = pd.read_csv('run_data/details.csv')
    x = float(x)
    y = float(y)

    # x,y = validate_and_run(x,y,r)
    nearest = find_nearest_point(filename,x,y)
    x = nearest[0]
    y = nearest[1]
    index = nearest[2]
    
    rounded_x_data = np.round(data['x'].values, 2)
    rounded_y_data = np.round(data['y'].values, 2)
    z = -float(z)
    x = float(x)
    y = float(y)
    t = float(t)
    alpha = float(alpha)


    # index = np.where((abs(rounded_x_data - x) < 1) & (abs(rounded_y_data - y) < 1))
    # if len(index[0]) == 0:
    #     print(f"No matching point found for approximate coordinates ({x}, {y})")
    #     return

    d = abs(data['Depth'].values[index])
    l = data['Wavelength'].values[index]
    h = data['Updated Wave Height'].values[index]
    theory = data['Theory'].values[index] 

    if(theory == 'Stokes 5th Order Wave Theory' and d/l> 0.07):
        result = plot.plot_wave_properties(t,h,x,z,y,d,l,alpha,index)

    elif(theory == "Stokes 3rd Order Wave Theory"):
        result = plot.stokes3rd_wave_calculations(t,h,x,y,z,alpha,index)
    elif(theory == "Stokes 2nd Order Wave Theory"):
        result = plot.stokes_2nd_wave_plot(x,y,z,t,h,d,alpha,index)
    else:
        result = plot.linear_wave_plot(x,y,z,t,h,d,alpha,index)
    return result








