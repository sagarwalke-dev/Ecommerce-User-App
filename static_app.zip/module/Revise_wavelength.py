import numpy as np
import math

def revise(l,h,d,t,theory,old_theory):
    if(h == 0):
         L = 0
         return L 
    L = 0
    if (theory == "Stokes 3rd Order Wave Theory"):
        a = h / 2
     
        # Iterate to find the wavelength L using linear wave theory
        while abs(L - l) > 0.001:
            L = l
            try:
                l = 1.56 * t * t * math.tanh(2 * math.pi * d / l)
            except ZeroDivisionError:
                print("Error: Division by zero encountered in calculation. Check input values.")
                break


        # Iterate to find the wavelength L using Stokes 3rd order wave theory
        while abs(L - l) > 0.001:
            L =  l
            k = 2 * math.pi / L
            
            # Avoid division by zero
            sinh_kd = math.sinh(k * d)
            if sinh_kd == 0:
                print("Error: Division by zero encountered in calculation. Check input values.")
                L = l
                break
            
            try:
                l = 1.56 * t * t * math.tanh(k * d) * (1 + (k * a * a) * ((5 + 2 * math.cosh(2 * k * d) + (2 * (math.cosh(2 * k * d) ** 2))) / (8 * (sinh_kd ** 4))))
            except ZeroDivisionError:
                print("Error: Please check if Stokes 3rd order theory is applicable or not")
                L = l
                break
    elif(theory == "Stokes 5th Order Wave Theory"):
        g = 9.81  # Gravity acceleration (m/s^

        # Define the system of equations
    def constants(kd):
        try:
            safe_values = np.clip(kd, -709, 709)
            s = np.sinh(safe_values)
            c = np.cosh(safe_values)
            c = np.clip(c, -1e2, 1e2)  # Adjust limits as needed
            s = np.clip(s, -1e2, 1e2)
            if( c == 0):
                c = 1
            if ( s == 0):
                s = 1


            A11 = 1/s
        
            A13 = np.nan_to_num(-(c**2)*(5*(c**2) + 1)/(8*(s**5)), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
            A15 = np.nan_to_num(-(1184*(c**10) - 1440*(c**8) - 1992*(c**6) + 2641*(c**4) - 249*(c**2)+ 18)/(1536*(s**11)), nan=0.0, posinf=1e+150, neginf=-1e+150)
            A22 = 3/(8*(s**4))

            A24 = np.nan_to_num((192*(c**8) - 424*(c**6) - 312*(c**4) + 480*(c**2) - 17)/(748*(s**10)), nan=0.0, posinf=1e+150, neginf=-1e+150)

            A33 = np.nan_to_num((13 - 4*(c**2))/(64*(s**7)), nan=0.0, posinf=1e+150, neginf=-1e+150)

            A35 = np.nan_to_num( (512*(c**12) + 4224*(c**10) - 6800*(c**8) - 12808*(c**6) + 16704*(c**4) - 3154*(c**2)+ 107)/(4096*(s**13)*(-1+ 6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
            
            A44 = np.nan_to_num((80*(c**6) - 816*(c**4) + 1338*(c**2) - 197)/((1536*(s**10)*(-1+6*(c**2)))), nan=0.0, posinf=1e+150, neginf=-1e+150)
            A55 = -( 2880*(c**10) - 72480*(c**8) + 324000*(c**6) - 432000*(c**4) + 163470*(c**2) - 16245)/(61440*(s**11)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4)))
            
            B22 = (1 + 2*(c**2))*c/(4*(s**3))

            B24 = np.nan_to_num(c*(272*(c**8) - 504*(c**6) - 192*(c**4) + 322*(c**2)+ 21)/(384*(s**9)), nan=0.0, posinf=1e+150, neginf=-1e+150)
            
            B33 = np.nan_to_num((1 + 8*(c**6))*3/(64*(s**6)), nan=0.0, posinf=1e+150, neginf=-1e+150)

            B35 = np.nan_to_num((88128*(c**14) - 208224*(c**12) + 70848*(c**10) + 54000*(c**8) - 21816*(c**6) + 6264*(c**4) - 54*(c**2)+ 81)/(12288*(s**12)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
            
            B44 = np.nan_to_num(c*(768*(c**10) - 448*(c**8) - 48*(c**6) + 48*(c**4) - 106*(c**2) -21)/(384*(s**9)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
            
            B55 = np.nan_to_num(-(192000*(c**16) - 262720*(c**14) + 83680*(c**12) + 20160*(c**10) - 7280*(c**8) + 7160*(c**6) - 1800*(c**4) - 1050*(c**2) + 225)/(12288*(s**10)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4))), nan=0.0, posinf=1e+150, neginf=-1e+150)
            C1 = (8*(c**4) - 8*(c**2) + 9)/(8*(s**4))
            C2 = (3840*(c**12) - 4096*(c**10) + 2592*(c**8) - 1008*(c**6) + 5944*(c**4) - 1830*(c**2)+ 147)/(512*(s**10)*(-1+6*(c**2)))
            C3 = -1/(4*s*c)

            C4 = np.nan_to_num(( 12*(c**8) + 36*(c**6) - 162*(c**4) + 141*(c**2) - 27)/(192*(s**9)*c), nan=0.0, posinf=1e+150, neginf=-1e+150)
        except:
            KeyError("check parameters")



            return A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4




        # Initial guess Kd
        Kd = 2*np.pi*d/l
        la = 1
        new_kd = 1
        while(abs((2*(np.pi)*d/Kd) - (2*(np.pi)*d/new_kd)) > 0.000001 ):
            new_kd = Kd
            l = la
            A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4 = constants(Kd)

            coefficients = [B55 + B35, 0, B33, 0, 1, -(h * Kd) / (2 * d)]
            if not np.any(np.isnan(coefficients)) and not np.any(np.isinf(coefficients)):
                L_prime = np.roots(coefficients)
            else:
                # Handle the case where coefficients are invalid
                L_prime = np.array([np.nan])
                break  # or any other fallback value
            L_prime = L_prime[np.isreal(L_prime)].real[0]  # Use the real root
            la = L_prime

            
            # Step 2: Recalculate Kd using the second equation
            kd = (4 * np.pi**2 * d) / (g * t**2) / (np.tanh(Kd) * (1 + C1 * L_prime**2 + C2 * L_prime**4))
        l = 2*(np.pi)*d/kd
    if ( old_theory and theory in ['Linear (Airy) Wave Theory','Stokes 2nd Order Wave Theory','Solitary or Cnoidal Wave Theory']):
        pass  
    elif(theory == 'Linear (Airy) Wave Theory' or theory =='Stokes 2nd Order Wave Theory'or theory =='Solitary or Cnoidal Wave Theory'):
        
        while abs(L - l) > 0.001:
            L = l
            try:
                l = 1.56 * t * t * math.tanh(2 * math.pi * d / l)
            except ZeroDivisionError:
                print("Error: Division by zero encountered in calculation. Check input values.")
                break
    return l

