import pandas as pd
import numpy as np
import module.Convert as cv
import os




def filter(filename,name):
    # Load the bathymetry CSV file
    cv.convert(filename)
    csv_file_path = os.path.join('utility', os.path.splitext(filename.filename)[0] + '_converted.csv')
    bathy_df = pd.read_csv(csv_file_path)

    # Start a new MATLAB session

    # Display the first few rows to understand its structure
    print("Original Bathy Data:")
    print(bathy_df.head())

    # Assuming the CSV has columns 'Latitude', 'Longitude', and 'GridCode'
    lat_column = 'latitude'  # Replace with actual column name if different
    lon_column = 'longitude'  # Replace with actual column name if different
    grid_code_column = 'grid_code'  # Replace with actual column name if different

    # 1. Round the latitude and longitude to the nearest 0.5
    bathy_df['Rounded_Latitude'] = bathy_df[lat_column].round(2)  # Adjust rounding precision as needed
    bathy_df['Rounded_Longitude'] = bathy_df[lon_column].round(2)  # Adjust rounding precision as needed

    # 2. Group by the new rounded latitude and longitude, and calculate the mean of the grid codes
    grouped_df = bathy_df.groupby(['Rounded_Latitude', 'Rounded_Longitude'])[grid_code_column].mean().reset_index()

    # 3. Rename columns for clarity in the output
    grouped_df.rename(columns={'Rounded_Latitude': 'latitude', 'Rounded_Longitude': 'longitude', grid_code_column: 'depth'}, inplace=True)

    # 4. Save the result to a new CSV file
    output_filename = 'utility/'+ name + 'bathy_grid.csv'
    grouped_df.to_csv(output_filename, index=False)




    data = pd.read_csv(output_filename)
    latitude_column = 'latitude'
    longitude_column = 'longitude'
    depth_column = 'depth'  # Assuming the depth column is named 'depth'

    # Find the minimum latitude and longitude to be the origin (0, 0)
    min_lat = data[latitude_column].min()
    min_lon = data[longitude_column].min()

    # Conversion factor: 1 degree = 100 km = 100,000 meters
    conversion_factor = 100000

    # Convert latitude and longitude to X, Y coordinates in meters
    data['Y'] = (data[longitude_column] - min_lon) * conversion_factor
    data['X'] = (data[latitude_column] - min_lat) * conversion_factor

    # Keep only the X, Y, and Depth columns
    data_converted = data[['X', 'Y', depth_column]]

    output_file_path = 'data/' +  name + 'converted_coordinates.csv'
    data_converted.to_csv(output_file_path, index=False)


    print(f"New CSV with averaged grid codes created successfully and saved as '{output_filename}'.")
    print("Sample of the new data:")
    print(grouped_df.head())

