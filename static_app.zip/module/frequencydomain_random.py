import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk

def frequency_domain(filename, canvas_frame):
    # Define column names based on the data structure
    column_names = ['Index', 'Date/Time', 'Water Level']  # Update as needed

    # Read the CSV file with specified column names
    data = pd.read_csv(filename, delimiter=',', skiprows=8, names=column_names)
    
    # Display the first few rows and column names for inspection
    print("Data Preview:")
    print(data.head())
    print("Column Names:", data.columns)

    # Convert the 'Date/Time' column to datetime format
    data['Date/Time'] = pd.to_datetime(data['Date/Time'], errors='coerce')  # Parse the 'Date/Time' column

    # Check if there are any NaT values and drop them if necessary
    if data['Date/Time'].isnull().any():
        print("Warning: Some date values could not be parsed. These rows will be dropped.")
        data = data.dropna(subset=['Date/Time'])  # Drop rows with NaT in the datetime column

    # Check the shape of the DataFrame after dropping rows
    print("Data Shape after Dropping NaT:", data.shape)

    # Adjust the index for eta if needed based on the actual column names
    eta = data['Water Level']  # Use the correct column name for water level

    # Perform FFT
    N = len(eta)
    if N == 0:
        print("No data available for FFT.")
        return

    # Calculate the sampling period
    T = (data['Date/Time'].iloc[-1] - data['Date/Time'].iloc[0]).total_seconds() / N  # Sampling period
    yf = np.fft.fft(eta)
    xf = np.fft.fftfreq(N, T)[:N//2]  # Frequencies corresponding to FFT

    # Plot on matplotlib figure
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(xf, 2.0/N * np.abs(yf[:N//2]))
    ax.set_title('Frequency Domain')
    ax.set_xlabel('Frequency (Hz)')
    ax.set_ylabel('Magnitude')
    ax.grid()

    # Clear previous canvas if exists
    for widget in canvas_frame.winfo_children():
        widget.destroy()

    # Draw plot on tkinter canvas
    canvas = FigureCanvasTkAgg(fig, master=canvas_frame)
    canvas.draw()
    canvas.get_tk_widget().pack()

def plot_wave(filename):
    # Create a Tkinter window for the plot
    root = tk.Tk()
    root.title("Frequency Domain Plot")

    # Frame for the plot
    canvas_frame = tk.Frame(root)
    canvas_frame.pack(padx=10, pady=10)

    # Call the frequency_domain function to display the plot in the Tkinter canvas
    frequency_domain(filename, canvas_frame)

    root.mainloop()
