import pandas as pd
import numpy as np
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def plot_3d_curve_from_csv():
    """Load a CSV file and plot a 3D curve along with the Mean Sea Level (MSL) using Tkinter."""
    try:
        # Load the CSV file
        data = pd.read_csv('run_data/depth.csv')
        # Assuming the columns are named 'X', 'Y', 'Depth'
        x = data['X'].values
        y = data['Y'].values
        z = (data['Depth'].values)

        # Create a Tkinter window
        root = tk.Tk()
        root.title("3D Curve Plot")

        # Create a 3D plot
        fig = plt.Figure(figsize=(8, 6), dpi=100)
        ax = fig.add_subplot(111, projection='3d')

        # Create a grid for the seabed plot
        ax.plot_trisurf(x, y, z, cmap='gist_earth', linewidth=0.2)

        # Set labels and title
        ax.set_xlabel('X axis')
        ax.set_ylabel('Y axis')
        ax.set_zlabel('Z axis')
        ax.set_title('3D Curve and MSL from CSV Data')

        # Create a canvas for Matplotlib figure
        canvas = FigureCanvasTkAgg(fig, master=root)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

        # Add a button to close the plot window
        button = tk.Button(root, text="Close", command=root.quit)
        button.pack(side=tk.BOTTOM)

        # Start the Tkinter event loop
        tk.mainloop()

    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage:
# plot_3d_curve_from_csv('run_data/depth.csv')
