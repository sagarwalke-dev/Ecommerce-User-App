import numpy as np
import pandas as pd
import time
import math
import pandas as pd
import numpy as np
import time

def constants(kd):
    try:
        safe_values = np.clip(kd, -709, 709)
        s = np.sinh(safe_values)
        c = np.cosh(safe_values)
        c = np.clip(c, -1e2, 1e2)  # Adjust limits as needed
        s = np.clip(s, -1e2, 1e2)
        if( c == 0):
            c = 1
        if ( s == 0):
            s = 1


        A11 = 1/s
      
        A13 = np.nan_to_num(-(c**2)*(5*(c**2) + 1)/(8*(s**5)), nan=0.0, posinf=1e+150, neginf=-1e+150)
       
        A15 = np.nan_to_num(-(1184*(c**10) - 1440*(c**8) - 1992*(c**6) + 2641*(c**4) - 249*(c**2)+ 18)/(1536*(s**11)), nan=0.0, posinf=1e+150, neginf=-1e+150)
        A22 = 3/(8*(s**4))

        A24 = np.nan_to_num((192*(c**8) - 424*(c**6) - 312*(c**4) + 480*(c**2) - 17)/(748*(s**10)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        A33 = np.nan_to_num((13 - 4*(c**2))/(64*(s**7)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        A35 = np.nan_to_num( (512*(c**12) + 4224*(c**10) - 6800*(c**8) - 12808*(c**6) + 16704*(c**4) - 3154*(c**2)+ 107)/(4096*(s**13)*(-1+ 6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        A44 = np.nan_to_num((80*(c**6) - 816*(c**4) + 1338*(c**2) - 197)/((1536*(s**10)*(-1+6*(c**2)))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        A55 = -( 2880*(c**10) - 72480*(c**8) + 324000*(c**6) - 432000*(c**4) + 163470*(c**2) - 16245)/(61440*(s**11)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4)))
        
        B22 = (1 + 2*(c**2))*c/(4*(s**3))

        B24 = np.nan_to_num(c*(272*(c**8) - 504*(c**6) - 192*(c**4) + 322*(c**2)+ 21)/(384*(s**9)), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B33 = np.nan_to_num((1 + 8*(c**6))*3/(64*(s**6)), nan=0.0, posinf=1e+150, neginf=-1e+150)

        B35 = np.nan_to_num((88128*(c**14) - 208224*(c**12) + 70848*(c**10) + 54000*(c**8) - 21816*(c**6) + 6264*(c**4) - 54*(c**2)+ 81)/(12288*(s**12)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B44 = np.nan_to_num(c*(768*(c**10) - 448*(c**8) - 48*(c**6) + 48*(c**4) - 106*(c**2) -21)/(384*(s**9)*(-1+6*(c**2))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        
        B55 = np.nan_to_num(-(192000*(c**16) - 262720*(c**14) + 83680*(c**12) + 20160*(c**10) - 7280*(c**8) + 7160*(c**6) - 1800*(c**4) - 1050*(c**2) + 225)/(12288*(s**10)*(-1+6*(c**2))*(3 - 11*(c**2) + 8*(c**4))), nan=0.0, posinf=1e+150, neginf=-1e+150)
        C1 = (8*(c**4) - 8*(c**2) + 9)/(8*(s**4))
        C2 = (3840*(c**12) - 4096*(c**10) + 2592*(c**8) - 1008*(c**6) + 5944*(c**4) - 1830*(c**2)+ 147)/(512*(s**10)*(-1+6*(c**2)))
        C3 = -1/(4*s*c)

        C4 = np.nan_to_num(( 12*(c**8) + 36*(c**6) - 162*(c**4) + 141*(c**2) - 27)/(192*(s**9)*c), nan=0.0, posinf=1e+150, neginf=-1e+150)
    except:
        KeyError("check parameters")



    return A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4



def generate_wave(theta,T, s_time):

    theta = float(theta)
    T = float(T)

    # Load data from the CSV file
    seabed_data = pd.read_csv('run_data/details.csv')



    # Extract relevant columns
    x = seabed_data['x']  # Assuming 'x' is one of the columns
    y = seabed_data['y']  # Assuming 'y' is one of the columns
    l = seabed_data['Wavelength']  # Assuming 'l' is one of the columns
    theory = seabed_data['Theory']  # Assuming 'theory' is one of the columns
    height = seabed_data['Updated Wave Height']  # Assuming 'height' is one of the columns
    depth = seabed_data['Depth']

    t = time.time() - s_time
    # Calculate wave_z based on the theory
    wave_z = np.zeros(len(x))  # Initialize wave_z array

    for i in range(len(x)):
        H = height[i]
        a = H/2
        L = l[i]
        d = abs(depth[i])
        r = x[i] * np.sin(math.radians(theta)) + y[i] * np.cos(math.radians(theta))
      
        if( L == 0):
            wave_z[i] = 0
        else:
            k = 2*np.pi/L
        

            if (theory[i]== 'Stokes 2nd Order Wave Theory'):
                
                wave_z[i] = (H / 2 * np.sin(k * r - (2 * np.pi / T) * t)) + (np.pi*H**2/8/L)*(np.cosh(k*d)/((np.sinh(k*d))**3))*(2 + np.cosh(2*k*d))*(np.cos(2*(k * r - (2 * np.pi / T) * t)))

            elif (theory[i]== 'Stokes 3rd Order Wave Theory'):
                omega = 2 * np.pi / T  # Angular frequency
                Theta = (k*r - omega*t)
                f2 = (np.cosh(k*d)*(np.cosh((2*k*d))+2))/(2*((np.sinh(k*d))**3))
                f3 = (3/16)*((8*((np.cosh(k*d))**6))+1)/((np.sinh(k*d))**6)
                A1 = H/(2*L)
                A2 = np.pi * A1**2 * f2
                A3 = ((np.pi)**2)*(A1**3)*f3
                wave_z[i] = L*((A1*np.cos(Theta)) + (A2*np.cos(2*Theta)) + (A3*np.cos(3*Theta)))  
            
            elif(d/L > 0.07 and theory[i]== 'Stokes 5th Order Wave Theory'):
                g = 9.81
                la = 1
                new_kd = 2*np.pi*d/L
                Kd = 2*np.pi*d/1.56/T**2
                counter = 0
                while(abs((2*(np.pi)*d/Kd) - (2*(np.pi)*d/new_kd)) > 0.01 ):
                    Kd = new_kd
                    A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4 = constants(Kd)

                    # Solve the system of equations
                    coefficients = [B55 + B35, 0, B33, 0, 1, -(H * Kd) / (2 * d)]
                    if not np.any(np.isnan(coefficients)) and not np.any(np.isinf(coefficients)):
                        L_prime = np.roots(coefficients)
                    else:
                        # Handle the case where coefficients are invalid
                        L_prime = np.array([np.nan])
                        break  # or any other fallback value

                    L_prime = L_prime[np.isreal(L_prime)].real[0]  # Use the real root
                    la = L_prime

            
                    # Step 2: Recalculate Kd using the second equation
                    new_kd = (4 * np.pi**2 * d) / (g * T**2) / (np.tanh(Kd) * (1 + C1 * L_prime**2 + C2 * L_prime**4))
                    counter += 1
                    if counter == 20:
                        break


                kd = new_kd
                L = 2*(np.pi)*d/kd
                A11,A13,A15,A22,A24,A33,A35,A44,A55,B22,B24,B33,B35,B44,B55,C1,C2,C3,C4 = constants(kd)


                # more constants
                C5 = abs((g*d/kd)*np.tanh(kd)*(1 + C1*la**2 + C2*la**4)) # celerity
                A1 = (A11*la**1 + A13*la**3 + A15*la**5)
                A2 = (A22*la**2 + A24*la**4)
                A3 = (A33*la**3 + A35*la**5)
                A4 = (A44*la**4)
                A5 = (A55*la**5)
                B3 = (B33*la**3 + B35*la**5)
                B2 = (B22*la**2 + B24*la**4)
                B5 = (A55*la**5)
                B4 = (B44*la**4)
                B1 = (la)
                k = kd/d
                o = t
                wave_z[i] = (1/k)*(B1*np.cos(k*r - 2*np.pi*o/T) + B2*np.cos(2*(k*r -2*np.pi*o/T)) + B3*np.cos(3*(k*r -2*np.pi*o/T)) + B4*np.cos(4*(k*r -2*np.pi*o/T))+ B5*np.cos(5*(k*r -2*np.pi*o/T)))

            else:
                wave_z[i] = H / 2 * np.sin(k * r - (2 * np.pi / T) * t)

    # Combine x, y, and wave_z into a DataFrame
    wave_data = pd.DataFrame({'x': x, 'y': y, 'wave_z': wave_z})
    return wave_data
