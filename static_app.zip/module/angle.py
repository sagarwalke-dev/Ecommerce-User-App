import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import argparse
import math

parser = argparse.ArgumentParser(description='Calculate Kr')

parser.add_argument('--A', type=float, required=True, help='Degree, with respect to Global North')

args = parser.parse_args()


alpha = math.degrees(args.A)  # Alpha_o (from command-line argument)


# Load the dataset (replace 'wavelength.csv' with your file path if needed)
data = pd.read_csv('utility\wavelength.csv')

# Define tolerance and target ratio
tolerance = 0.002  # 0.2 percent tolerance
target_ratio = 0.5

# Calculate the ratio of absolute depth to wavelength

data['depth_wavelength_ratio'] = np.abs(data['Depth']) / data['l']

# Filter the points where the ratio is within the specified tolerance range
filtered_points = data[np.abs(data['depth_wavelength_ratio'] - target_ratio) <= tolerance].copy()

# Initialize list to store angles
incident_angle = []

# Loop through each point in filtered_points and calculate the angle
for i in range(len(filtered_points)):
    if i == 0:  # First point: use next point (i+1) for slope calculation
        x1, x2 = filtered_points['X'].iloc[i], filtered_points['X'].iloc[i + 1]
        y1, y2 = filtered_points['Y'].iloc[i], filtered_points['Y'].iloc[i + 1]
    elif i == len(filtered_points) - 1:  # Last point: use previous point (i-1)
        x1, x2 = filtered_points['X'].iloc[i - 1], filtered_points['X'].iloc[i]
        y1, y2 = filtered_points['Y'].iloc[i - 1], filtered_points['Y'].iloc[i]
    else:  # Middle points: use (i-1) and (i+1) for slope calculation
        x1, x2 = filtered_points['X'].iloc[i - 1], filtered_points['X'].iloc[i + 1]
        y1, y2 = filtered_points['Y'].iloc[i - 1], filtered_points['Y'].iloc[i + 1]

    # Calculate slope and angle with y-axis
    slope = (y2 - y1) / (x2 - x1) if (x2 - x1) != 0 else np.inf
    angle = np.arctan(1/slope) if slope != 0 else np.arctan(np.inf) # Angle in radians
    angle = math.radians(min(abs((alpha - math.degrees(angle) + 90)%360 - 180),90))
    incident_angle.append(angle)

# Add the calculated angles to the filtered points DataFrame
filtered_points['incident_angle'] = incident_angle

# Now propagate the angle for x > x0 where y = y0 across the entire original dataset
for y0 in filtered_points['Y'].unique():
    # Get the points where y = y0 from the filtered points
    points_at_y0 = filtered_points[filtered_points['Y'] == y0]
    
    # Sort the points by X to ensure we propagate correctly
    points_at_y0 = points_at_y0.sort_values('X')
    
    if not points_at_y0.empty:
        # Get the angle at the first point (smallest x)
        angle_at_x0_y0 = points_at_y0['incident_angle'].iloc[0]
        
        # Apply this angle to all points in the original dataset where y = y0 and x > x0
        data.loc[(data['Y'] == y0) & (data['X'] >= points_at_y0['X'].iloc[0]), 'incident_angle'] = angle_at_x0_y0

# Save the updated DataFrame with the angles to a new CSV file
data.to_csv('utility\wavelength_with_angles.csv', index=False)
