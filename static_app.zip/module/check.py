import subprocess
import math
import pandas as pd
import wavetheory as wt
import numpy as np
import Revise_wavelength as rw
import argparse
# Constants
g = 9.81  # acceleration due to gravity (m/s^2)
rho = 1025  # density of seawater (kg/m^3)

# Load data from CSV
data = pd.read_csv('utility\WaveHeight.csv')

# Set up argument parsing to get values from command-line inputs
parser = argparse.ArgumentParser(description='Calculate Wave properties for the wave')
parser.add_argument('--T', type=float, required=True, help='Wave period in seconds')
parser.add_argument('--A', type=float, required=True, help='degrees, with respect to global north')
parser.add_argument('--H', type=float, required=True, help='Wave Height in m')
args = parser.parse_args()

# Round the input x and y to two decimal places
t = args.T  # Wave period (from command-line argument)
alpha = args.A
h = args.H

subprocess.run(['python', 'module/Wavelength.py','--T',str(t)])
change = 1

data = pd.read_csv('utility\wavelength.csv')

theory = data['Theory'].values
depth = -data['Depth'].values #since depth is negative


while(change!=0):
    change = 0
    subprocess.run(['python', 'module/angle.py','--A',str(math.radians(alpha))])

    subprocess.run(['python', 'module/refraction.py'])

    subprocess.run(['python', 'module/wave_height.py','--T',str(t),'--H',str(h)])
    new_data = pd.read_csv('utility\WaveHeight.csv')
    height = new_data['Updated Wave Height'].values
    length = new_data['Wavelength'].values

    new_length = []
    Theory = []

    i = 0
    for i in range(len(depth)):
        new_theory = wt.select_wave_theory_with_boundaries(height[i] , depth[i], t)
        Theory.append(new_theory)
        if (length[i]!=0):
            if(new_theory != theory[i]):
                new_length.append(rw.revise(length[i],height[i],depth[i],t,new_theory,theory[i]))
                change += 1
            else:
                new_length.append(length[i])
        else:
            new_length.append(length[i])

    new_data['Wavelength'] = new_length
    new_data.to_csv("utility\WaveHeight.csv", index=False)
    new_data["Theory"] = Theory
    new_data.to_csv("utility\WaveHeight.csv", index=False)

    theory = Theory

    pass

